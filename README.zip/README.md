# RecoverAI — Autonomous Failed Payment Recovery Agent

<div align="center">

![RecoverAI Banner](https://img.shields.io/badge/Track-AI%20Revenue%20Recovery-4f46e5?style=for-the-badge)
![FastAPI](https://img.shields.io/badge/FastAPI-0.110.0-009688?style=for-the-badge&logo=fastapi)
![XGBoost](https://img.shields.io/badge/XGBoost-ROC--AUC%200.9965-FF6600?style=for-the-badge)
![React](https://img.shields.io/badge/React%2018-TypeScript-61DAFB?style=for-the-badge&logo=react)
![Tailwind](https://img.shields.io/badge/Tailwind_CSS-Modern_Fintech-38B2AC?style=for-the-badge&logo=tailwind-css)

**"Turn Failed Payments Into Recovered Revenue."**

*A production-grade, autonomous payment recovery agent platform designed for modern fintechs and e-commerce merchants.*

</div>

---

## 1. Problem Statement

Payment failures represent a massive leakage in merchant revenue. Industry data indicates that **up to 15–20% of online payment attempts fail** due to temporary upstream bank timeouts, PSP switch latency, transient network drops, or expired cards. 

Historically, merchants had only two flawed choices:
1. **Dumb fixed retry loops** that spam declining cards, trigger fraud locks, and increase gateway penalties.
2. **Manual customer support outreach**, which is slow, expensive, and results in severe cart abandonment.

## 2. The Solution: RecoverAI

**RecoverAI** intercepts payment failures at the gateway boundary, performs ML-driven recoverability prediction, determines optimal recovery strategies using an autonomous ReAct reasoning agent, executes actions via simulated payment gateway tools, observes real-time outcomes, and recovers lost revenue with full explainability and human-in-the-loop safety controls.

```
Payment Failure ➔ AI Diagnostic ➔ ML Recoverability Scoring ➔ Agent Strategy ➔ Tool Execution ➔ Observation ➔ Revenue Recaptured
```

---

## 3. Key System Features

- **Autonomous ReAct Recovery Agent:** State-driven closed loop (Observe ➔ Reason ➔ Policy Guard ➔ Tool Act ➔ Observe Result).
- **Tabular ML Recoverability Engine:** Evaluated across Logistic Regression, Random Forest, and XGBoost (Best: **XGBoost, ROC-AUC: 0.9965, Precision: 0.9733, Recall: 0.9804**).
- **SHAP-Style Feature Explainability:** Converts complex mathematical feature weights into plain-language merchant rationales.
- **Strict Financial Safety Guardrails:** Hard caps on automated transaction amounts (₹25,000 / $300), maximum 3 retry attempts, and confidence floors (< 35% automated block).
- **Human-in-the-Loop Review Queue:** Dedicated interface for high-value and escalated payments with one-click approve/reject actions.
- **Realistic Payment Gateway Simulator:** Context-aware latency and probabilistic outcome generator with deterministic test seeds.
- **Modern Fintech SaaS Dashboard:** Clean blue/indigo aesthetic, interactive charts (Recharts), dynamic recovery timelines, and live agent event feeds.

---

## 4. End-to-End Architecture

```mermaid
graph TD
    subgraph Frontend ["Frontend (React 18 + TypeScript + Vite + Tailwind CSS)"]
        UI_Dash["Merchant Dashboard (/dashboard)"]
        UI_Txns["Failed Payments Table (/transactions)"]
        UI_Detail["Transaction & AI Timeline (/transactions/:id)"]
        UI_Human["Human Review Queue (/recovery)"]
        UI_Agent["Live Agent Activity Feed (/agent-activity)"]
        UI_Analytics["Revenue & ML Analytics (/analytics)"]
    end

    subgraph Backend ["Backend (FastAPI + Pydantic v2 + SQLAlchemy 2.0)"]
        API_Gateway["FastAPI REST Endpoints & CORS"]
        Txn_Service["Transaction & Analytics Service"]
        
        subgraph AgentEngine ["Autonomous Recovery Agent Engine"]
            Agent_Core["Recovery Agent (ReAct / State Loop)"]
            Safety_Guard["Safety & Policy Guardrails (Thresholds / Retries)"]
            Agent_Tools["Agent Recovery Tools (Retry, Schedule, Notify, Escalate)"]
            Audit_Logger["Audit & Decision Logger"]
        end

        subgraph MLEngine ["ML & Explainability Engine"]
            Model_Loader["Model Inference Service (XGBoost)"]
            SHAP_Explainer["Explainability Engine (Feature Contributions)"]
            Classifier["Failure Reason Classifier"]
        end

        subgraph Simulator ["Payment Gateway Simulator"]
            Gateway_Sim["Realistic Gateway Engine (Deterministic Seeds, Probabilistic Outcomes)"]
        end
    end

    subgraph Storage ["Database & Artifacts (PostgreSQL / SQLite)"]
        DB[(Transactions, Customers, Actions, Decisions, Audits)]
        ML_Artifacts[("Trained Models (xgboost_model.joblib, scaler.joblib, metadata.json)")]
    end

    UI_Dash -->|REST API| API_Gateway
    UI_Txns -->|REST API| API_Gateway
    UI_Detail -->|REST API| API_Gateway
    UI_Human -->|Approve / Reject Action| API_Gateway
    UI_Agent -->|Poll / Stream Events| API_Gateway
    UI_Analytics -->|REST API| API_Gateway

    API_Gateway --> Txn_Service
    API_Gateway --> Agent_Core
    
    Agent_Core --> Safety_Guard
    Agent_Core --> Agent_Tools
    Agent_Core --> Model_Loader
    Agent_Core --> SHAP_Explainer
    Agent_Core --> Audit_Logger

    Agent_Tools --> Gateway_Sim
    Agent_Tools --> DB
    Audit_Logger --> DB
    Txn_Service --> DB
    Model_Loader --> ML_Artifacts
```

---

## 5. Machine Learning Pipeline & Benchmark

The recoverability classifier was trained and evaluated on 12,000 statistically correlated payment transactions (`ml/generate_dataset.py`):

| Model | Accuracy | Precision (Recov.) | Recall (Recov.) | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression (Baseline)** | 90.33% | 91.73% | 94.31% | 0.9300 | 0.9686 |
| **Random Forest Classifier** | 94.25% | 93.75% | 98.10% | 0.9588 | 0.9901 |
| **XGBoost Classifier (Production)** | **96.83%** | **97.33%** | **98.04%** | **0.9768** | **0.9965** |

### Evaluation Confusion Matrix (Test Split N = 2,400):
- **True Positive (TP):** 1,603 (Correctly classified recoverable)
- **True Negative (TN):** 721 (Correctly classified non-recoverable)
- **False Positive (FP):** 44
- **False Negative (FN):** 32

---

## 6. Autonomous Recovery Agent Workflow

```mermaid
sequenceDiagram
    autonumber
    participant Merchant as Merchant / System
    participant Agent as Autonomous Recovery Agent
    participant Policy as Safety & Policy Engine
    participant ML as ML & SHAP Engine
    participant Sim as Payment Simulator
    participant DB as Database / Audit Log

    Merchant->>Agent: Ingest Failed Transaction (TXN10293)
    Agent->>DB: Fetch Customer Profile & Historical Payments
    Agent->>ML: Predict Recoverability & Extract SHAP Factors
    ML-->>Agent: Probability: 91%, Factors: [Bank Timeout, 87% Past Success]
    
    Agent->>Agent: Formulate Strategy (e.g. RETRY_LATER in 15 mins)
    Agent->>Policy: Evaluate Safety Guardrails (Threshold ₹25,000, Max Retries: 3)
    
    alt Violates Policy / High Value / Low Confidence
        Policy-->>Agent: Requires Human Approval
        Agent->>DB: Route to Human Review Queue (Status: PENDING_APPROVAL)
        Agent->>DB: Write Audit Log (Actor: AI_AGENT)
    else Passes Safety Policies
        Policy-->>Agent: Approved for Autonomous Execution
        Agent->>DB: Record AGENT_DECISION & Schedule Action
        Agent->>Sim: Execute Tool: retry_payment(TXN10293)
        Sim-->>Agent: Result: SUCCESS (Recovered ₹8,999, Latency: 195ms)
        Agent->>DB: Update Transaction (RECOVERED, recovered_at=now)
        Agent->>DB: Log Audit & Emit Activity Stream
    end
```

---

## 7. 5-Minute Presentation Demo Scenario

RecoverAI includes a deterministic pre-seeded demo transaction (`TXN-DEMO-001`) designed for technical presentations:

| Parameter | Value |
| :--- | :--- |
| **Transaction ID** | `TXN-DEMO-001` |
| **Amount** | ₹8,999.00 |
| **Customer** | Rahul Sharma (`CUST-1001`, Premium Tier, 85.7% Historical Success) |
| **Failure Reason** | `BANK_TIMEOUT` (Transient switch error `PSP_TIMEOUT_504`) |
| **Initial Status** | `FAILED` |
| **ML Probability** | `91% (High Confidence)` |
| **Agent Decision** | `RETRY_LATER` |
| **Simulated Result** | `SUCCESS` (₹8,999 captured, Auth: `AUTH99812`) |

### How to Run Demo:
1. Open the dashboard at `http://localhost:5173`.
2. Click **"Run Autonomous Demo"** on the top banner.
3. Observe the dynamic timeline update in real-time, the transaction move to `RECOVERED`, and the recovered revenue KPI increment instantly!

---

## 8. Quickstart & Local Setup

### Prerequisites:
- Python 3.11+
- Node.js 18+ and npm

### 1. Backend & ML Pipeline:
```powershell
# In terminal 1:
# Install dependencies
pip install -r backend/requirements.txt

# Generate synthetic dataset (12,000 records)
python ml/generate_dataset.py

# Train & benchmark ML models (Logistic Regression, Random Forest, XGBoost)
python ml/train.py
python ml/evaluate.py

# Seed database with initial customers and transactions
python -m backend.app.database.seed_data

# Start FastAPI backend
python -m uvicorn backend.app.main:app --reload --port 8000
```
- API is live at `http://localhost:8000`
- Interactive Swagger documentation at `http://localhost:8000/docs`

### 2. Frontend:
```powershell
# In terminal 2:
cd frontend
npm install
npm run dev
```
- Frontend is live at `http://localhost:5173`

### 3. Run Automated Tests:
```powershell
python -m pytest backend/tests -v
```

---

## 9. Docker Deployment (Single Command)

```bash
docker compose up --build
```
- Frontend: `http://localhost:5173`
- Backend: `http://localhost:8000`
- PostgreSQL: `localhost:5432`

---

## 10. Responsible AI & Financial Safety

- **Zero Real Financial Transactions:** RecoverAI operates exclusively against a simulated banking gateway. No real credit cards or bank accounts are ever charged.
- **Deterministic Guardrails:** High-value transactions (> ₹25,000) and low-confidence predictions (< 35%) are strictly intercepted and routed to human review.
- **Audit Logging:** Every autonomous decision, factor attribution, and tool call is permanently immutably logged with actor tracking (`SYSTEM`, `AI_AGENT`, `MERCHANT`).

---

## 11. Authors & License

- **Project:** RecoverAI — Autonomous Failed Payment Recovery Agent
- **Track:** AI Revenue Recovery
- **License:** MIT License
