import os
import sys
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc

# Handle Windows terminal utf-8
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Add root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from backend.app.ml.preprocessing import prepare_features

def evaluate_model():
    artifacts_dir = "ml/artifacts"
    model_path = os.path.join(artifacts_dir, "xgboost_recovery_model.joblib")
    features_path = os.path.join(artifacts_dir, "feature_columns.json")
    dataset_path = "data/synthetic_failed_payments.csv"
    
    if not os.path.exists(model_path) or not os.path.exists(features_path):
        raise FileNotFoundError("Model or feature mapping not found. Run train.py first.")
        
    model = joblib.load(model_path)
    with open(features_path, "r") as f:
        feature_columns = json.load(f)
        
    df = pd.read_csv(dataset_path)
    y = df["recoverable"].values
    X_encoded, _ = prepare_features(df, is_training=False, feature_columns=feature_columns)
    
    _, X_test, _, y_test = train_test_split(
        X_encoded, y, test_size=0.20, random_state=42, stratify=y
    )
    
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    
    cm = confusion_matrix(y_test, y_pred).tolist()
    report = classification_report(y_test, y_pred, output_dict=True)
    
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    roc_auc = auc(fpr, tpr)
    
    # Feature importances
    importances = model.feature_importances_
    feat_imp = sorted(
        [{"feature": col, "importance": round(float(imp), 4)} for col, imp in zip(feature_columns, importances)],
        key=lambda x: x["importance"],
        reverse=True
    )
    
    eval_summary = {
        "metrics": {
            "accuracy": round(float(report["accuracy"]), 4),
            "precision_recoverable": round(float(report["1"]["precision"]), 4),
            "recall_recoverable": round(float(report["1"]["recall"]), 4),
            "f1_recoverable": round(float(report["1"]["f1-score"]), 4),
            "roc_auc": round(float(roc_auc), 4),
            "total_test_samples": len(y_test)
        },
        "confusion_matrix": {
            "true_negative": cm[0][0],
            "false_positive": cm[0][1],
            "false_negative": cm[1][0],
            "true_positive": cm[1][1]
        },
        "top_features": feat_imp[:12],
        "detailed_classification_report": report
    }
    
    eval_file = os.path.join(artifacts_dir, "evaluation_report.json")
    with open(eval_file, "w") as f:
        json.dump(eval_summary, f, indent=2)
        
    print("[RecoverAI ML Evaluation]")
    print(f" -> Accuracy: {eval_summary['metrics']['accuracy']}")
    print(f" -> Precision (Class 1): {eval_summary['metrics']['precision_recoverable']}")
    print(f" -> Recall (Class 1): {eval_summary['metrics']['recall_recoverable']}")
    print(f" -> F1 Score (Class 1): {eval_summary['metrics']['f1_recoverable']}")
    print(f" -> ROC-AUC: {eval_summary['metrics']['roc_auc']}")
    print(f"\n[Confusion Matrix]\nTN: {cm[0][0]} | FP: {cm[0][1]}\nFN: {cm[1][0]} | TP: {cm[1][1]}")
    print(f"\n[Top 5 Predictive Features]:")
    for item in feat_imp[:5]:
        print(f" - {item['feature']}: {item['importance']}")
    print(f"\n[SUCCESS] Evaluation report saved to {eval_file}")
    
    return eval_summary

if __name__ == "__main__":
    evaluate_model()
