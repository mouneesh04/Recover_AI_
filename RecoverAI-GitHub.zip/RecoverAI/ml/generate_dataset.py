import os
import sys
import random
import numpy as np
import pandas as pd

# Handle Windows terminal utf-8
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Set fixed seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

LOCATIONS = ["Mumbai, IN", "Bengaluru, IN", "Delhi NCR, IN", "Hyderabad, IN", "Chennai, IN", "Pune, IN", "Kolkata, IN", "Ahmedabad, IN"]
PAYMENT_METHODS = ["CARD", "UPI", "NETBANKING", "WALLET"]
DEVICE_TYPES = ["MOBILE", "DESKTOP", "TABLET"]

FAILURE_REASONS = [
    "BANK_TIMEOUT",
    "NETWORK_ERROR",
    "INSUFFICIENT_FUNDS",
    "CARD_EXPIRED",
    "INVALID_DETAILS",
    "BANK_DECLINED",
    "UPI_FAILURE",
    "GATEWAY_ERROR",
    "CUSTOMER_ABANDONED",
    "UNKNOWN"
]

def generate_synthetic_payments(num_records: int = 12000) -> pd.DataFrame:
    """
    Generates a realistic, statistically correlated dataset of failed payment transactions
    specifically designed for training RecoverAI's recoverability prediction model.
    """
    records = []
    
    # Generate a pool of 2,000 distinct customers with realistic profiles
    customers = []
    for i in range(1, 2001):
        cust_id = f"CUST-{1000 + i}"
        total_txns = max(1, int(np.random.exponential(scale=12)))
        success_rate = min(1.0, max(0.2, np.random.beta(a=8, b=2)))
        succ_txns = int(total_txns * success_rate)
        fail_txns = total_txns - succ_txns
        avg_amount = round(float(np.random.lognormal(mean=7.5, sigma=0.8)), 2) # avg around ₹2,000 - ₹15,000
        tier = "VIP" if avg_amount > 15000 and success_rate > 0.85 else ("PREMIUM" if success_rate > 0.8 else "STANDARD")
        
        customers.append({
            "customer_id": cust_id,
            "total_transactions": total_txns,
            "previous_successful_transactions": succ_txns,
            "previous_failed_transactions": fail_txns,
            "previous_success_rate": round(succ_txns / total_txns, 3),
            "average_transaction_amount": avg_amount,
            "customer_tier": tier,
            "customer_age_days": random.randint(15, 750),
            "preferred_method": random.choice(PAYMENT_METHODS)
        })
    
    for idx in range(1, num_records + 1):
        txn_id = f"TXN-{100000 + idx}"
        customer = random.choice(customers)
        
        # Transaction Amount with realistic distribution around customer's normal average
        amount_factor = max(0.2, np.random.normal(loc=1.0, scale=0.35))
        amount = round(float(customer["average_transaction_amount"] * amount_factor), 2)
        amount_deviation = round(amount / max(1.0, customer["average_transaction_amount"]), 3)
        
        hour = random.choices(
            population=list(range(24)),
            weights=[2, 1, 1, 1, 2, 3, 5, 8, 10, 12, 14, 15, 14, 13, 14, 15, 16, 17, 18, 16, 14, 10, 6, 4]
        )[0]
        day_of_week = random.randint(0, 6) # 0=Monday, 6=Sunday
        
        device = random.choices(DEVICE_TYPES, weights=[0.72, 0.23, 0.05])[0]
        payment_method = random.choices(
            [customer["preferred_method"], random.choice(PAYMENT_METHODS)],
            weights=[0.8, 0.2]
        )[0]
        location = random.choice(LOCATIONS)
        
        # Retry count
        retry_count = random.choices([0, 1, 2, 3], weights=[0.65, 0.20, 0.10, 0.05])[0]
        time_since_last_txn = round(random.uniform(0.5, 360.0), 1)
        is_first_txn = 1 if customer["total_transactions"] <= 1 else 0
        
        # Bank response time & network latency
        is_night_maintenance = 1 if 1 <= hour <= 4 else 0
        network_latency = int(np.random.normal(loc=120 if not is_night_maintenance else 450, scale=35))
        network_latency = max(20, min(2500, network_latency))
        
        bank_response_time = int(np.random.normal(loc=650 if not is_night_maintenance else 3800, scale=200))
        bank_response_time = max(100, min(9000, bank_response_time))
        
        # Determine failure reason correlated with context
        if is_night_maintenance and random.random() < 0.6:
            failure_reason = random.choice(["BANK_TIMEOUT", "GATEWAY_ERROR", "UPI_FAILURE"])
        elif payment_method == "UPI" and random.random() < 0.45:
            failure_reason = random.choice(["UPI_FAILURE", "BANK_TIMEOUT", "NETWORK_ERROR"])
        elif payment_method == "CARD" and random.random() < 0.25:
            failure_reason = random.choice(["CARD_EXPIRED", "BANK_DECLINED", "INVALID_DETAILS"])
        else:
            failure_reason = random.choices(
                FAILURE_REASONS,
                weights=[0.24, 0.16, 0.18, 0.06, 0.05, 0.12, 0.10, 0.05, 0.03, 0.01]
            )[0]
            
        # Ground Truth Recoverability Formula based on real fintech mechanics:
        score = 0.0
        
        # 1. Failure Reason impact
        if failure_reason in ["BANK_TIMEOUT", "NETWORK_ERROR", "GATEWAY_ERROR"]:
            score += 2.2
        elif failure_reason in ["UPI_FAILURE"]:
            score += 1.6
        elif failure_reason in ["INSUFFICIENT_FUNDS"]:
            score += 0.4
        elif failure_reason in ["CUSTOMER_ABANDONED"]:
            score += 0.8
        elif failure_reason in ["BANK_DECLINED"]:
            score -= 0.6
        elif failure_reason in ["CARD_EXPIRED", "INVALID_DETAILS"]:
            score -= 2.5
        elif failure_reason in ["UNKNOWN"]:
            score -= 0.5
            
        # 2. Customer historical fidelity
        score += (customer["previous_success_rate"] - 0.5) * 3.2
        if customer["previous_successful_transactions"] >= 5:
            score += 0.8
        if is_first_txn:
            score -= 0.6
            
        # 3. Retry count penalty (decay per attempt)
        score -= retry_count * 1.3
        
        # 4. Amount anomaly penalty
        if amount_deviation > 2.5:
            score -= 1.1
        elif 0.8 <= amount_deviation <= 1.2:
            score += 0.5
            
        # 5. Latency/Night effects
        if is_night_maintenance and failure_reason in ["BANK_TIMEOUT", "GATEWAY_ERROR"]:
            score += 0.8 # Highly recoverable once maintenance window ends
            
        # Convert log-odds score to probability via sigmoid + slight noise
        prob = 1.0 / (1.0 + np.exp(-score))
        prob = np.clip(prob + np.random.normal(0, 0.04), 0.01, 0.99)
        
        recoverable = 1 if prob >= 0.50 else 0
        
        # Strategy selection
        if failure_reason in ["BANK_TIMEOUT", "UPI_FAILURE"] and retry_count < 3:
            strategy = "RETRY_LATER"
        elif failure_reason in ["NETWORK_ERROR", "GATEWAY_ERROR"] and retry_count == 0:
            strategy = "RETRY_NOW"
        elif failure_reason == "INSUFFICIENT_FUNDS":
            strategy = "SEND_PAYMENT_REMINDER"
        elif failure_reason in ["CARD_EXPIRED", "BANK_DECLINED", "INVALID_DETAILS"]:
            strategy = "SUGGEST_ALTERNATIVE_PAYMENT_METHOD"
        elif amount > 25000 or retry_count >= 3 or prob < 0.35:
            strategy = "ESCALATE_TO_HUMAN"
        else:
            strategy = "DO_NOT_RETRY" if prob < 0.2 else "RETRY_LATER"

        # Historical recovery rate for feature tracking
        hist_rec_rate = round(0.88 if failure_reason == "BANK_TIMEOUT" else (0.75 if failure_reason == "NETWORK_ERROR" else 0.42), 2)
        
        records.append({
            "transaction_id": txn_id,
            "customer_id": customer["customer_id"],
            "amount": amount,
            "payment_method": payment_method,
            "device_type": device,
            "location": location,
            "hour": hour,
            "day_of_week": day_of_week,
            "customer_age_days": customer["customer_age_days"],
            "previous_transactions": customer["total_transactions"],
            "previous_successful_transactions": customer["previous_successful_transactions"],
            "previous_failed_transactions": customer["previous_failed_transactions"],
            "previous_success_rate": customer["previous_success_rate"],
            "average_transaction_amount": customer["average_transaction_amount"],
            "amount_deviation": amount_deviation,
            "retry_count": retry_count,
            "time_since_last_transaction_hours": time_since_last_txn,
            "is_first_transaction": is_first_txn,
            "network_latency_ms": network_latency,
            "bank_response_time_ms": bank_response_time,
            "failure_reason": failure_reason,
            "historical_recovery_rate": hist_rec_rate,
            "optimal_strategy": strategy,
            "recovery_probability": round(float(prob), 4),
            "recoverable": recoverable
        })
        
    df = pd.DataFrame(records)
    return df

if __name__ == "__main__":
    os.makedirs("ml/artifacts", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    
    print("[RecoverAI] Generating synthetic payment dataset...")
    df = generate_synthetic_payments(num_records=12000)
    
    csv_path = "data/synthetic_failed_payments.csv"
    df.to_csv(csv_path, index=False)
    
    print(f"[SUCCESS] Generated {len(df)} transactions -> {csv_path}")
    print(f"[METRICS] Recoverable class distribution:\n{df['recoverable'].value_counts(normalize=True).round(3)}")
    print(f"[METRICS] Failure reasons breakdown:\n{df['failure_reason'].value_counts()}")
