import os
import sys
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from xgboost import XGBClassifier

# Handle Windows terminal utf-8
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Add root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from backend.app.ml.preprocessing import prepare_features

def train_and_compare_models():
    dataset_path = "data/synthetic_failed_payments.csv"
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset not found at {dataset_path}. Run generate_dataset.py first.")
        
    print("[RecoverAI ML] Loading synthetic payment records...")
    df = pd.read_csv(dataset_path)
    
    y = df["recoverable"].values
    X_encoded, feature_columns = prepare_features(df, is_training=True)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_encoded, y, test_size=0.20, random_state=42, stratify=y
    )
    
    print(f"[RecoverAI ML] Training dataset size: {len(X_train)} samples, Test size: {len(X_test)} samples")
    print(f"[RecoverAI ML] Number of input features after encoding: {len(feature_columns)}")
    
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42),
        "XGBoost": XGBClassifier(
            n_estimators=150,
            max_depth=5,
            learning_rate=0.08,
            subsample=0.85,
            colsample_bytree=0.85,
            eval_metric="logloss",
            random_state=42
        )
    }
    
    results = {}
    best_model_name = None
    best_roc_auc = -1.0
    trained_model_objs = {}
    
    for name, model in models.items():
        print(f"\n[MODEL BENCHMARK] Training {name}...")
        model.fit(X_train, y_train)
        trained_model_objs[name] = model
        
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
        
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        auc = roc_auc_score(y_test, y_prob)
        
        results[name] = {
            "accuracy": round(float(acc), 4),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_score": round(float(f1), 4),
            "roc_auc": round(float(auc), 4)
        }
        
        print(f" -> Accuracy: {acc:.4f} | Precision: {prec:.4f} | Recall: {rec:.4f} | F1: {f1:.4f} | ROC-AUC: {auc:.4f}")
        
        if auc > best_roc_auc:
            best_roc_auc = auc
            best_model_name = name
            
    print(f"\n[WINNER] Best Performing Model: {best_model_name} (ROC-AUC: {best_roc_auc:.4f})")
    
    # Save artifacts
    artifacts_dir = "ml/artifacts"
    os.makedirs(artifacts_dir, exist_ok=True)
    
    best_model = trained_model_objs[best_model_name]
    model_path = os.path.join(artifacts_dir, "xgboost_recovery_model.joblib")
    features_path = os.path.join(artifacts_dir, "feature_columns.json")
    benchmark_path = os.path.join(artifacts_dir, "model_benchmark.json")
    
    joblib.dump(best_model, model_path)
    
    with open(features_path, "w") as f:
        json.dump(feature_columns, f, indent=2)
        
    with open(benchmark_path, "w") as f:
        json.dump({
            "best_model": best_model_name,
            "benchmark_comparison": results,
            "feature_count": len(feature_columns)
        }, f, indent=2)
        
    print(f"[SUCCESS] Saved model to {model_path}")
    print(f"[SUCCESS] Saved feature column mapping to {features_path}")
    print(f"[SUCCESS] Saved benchmark report to {benchmark_path}")
    
    return results

if __name__ == "__main__":
    train_and_compare_models()
