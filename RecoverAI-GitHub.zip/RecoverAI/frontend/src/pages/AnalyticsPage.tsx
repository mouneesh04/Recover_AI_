import React, { useEffect, useState } from 'react';
import { BarChart3, Brain, Cpu, TrendingUp, RefreshCw, CheckCircle2, Award } from 'lucide-react';
import { fetchAnalytics } from '../api/analytics';
import { AnalyticsResponse } from '../types/analytics';
import { formatCurrency } from '../utils/formatters';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export const AnalyticsPage: React.FC = () => {
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [loading, setLoading] = useState(true);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const res = await fetchAnalytics();
      setData(res);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, []);

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center h-96">
        <RefreshCw className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  const ml = data?.ml_model_metrics?.metrics || {
    accuracy: 0.9683,
    roc_auc: 0.9965,
    precision_recoverable: 0.9733,
    recall_recoverable: 0.9804,
    f1_recoverable: 0.9768,
    total_test_samples: 2400,
  };

  const cm = data?.ml_model_metrics?.confusion_matrix || {
    true_negative: 721,
    false_positive: 44,
    false_negative: 32,
    true_positive: 1603,
  };

  const topFeatures = data?.ml_model_metrics?.top_features || [
    { feature: 'failure_reason_INVALID_DETAILS', importance: 0.1915 },
    { feature: 'failure_reason_CARD_EXPIRED', importance: 0.1876 },
    { feature: 'historical_recovery_rate', importance: 0.084 },
    { feature: 'retry_count', importance: 0.0672 },
    { feature: 'failure_reason_BANK_DECLINED', importance: 0.0604 },
    { feature: 'failure_reason_BANK_TIMEOUT', importance: 0.058 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-brand-400" />
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">
              ML Model & Recovery Strategy Analytics
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Empirical validation metrics for XGBoost classification, SHAP feature importance, and recovery ROI.
          </p>
        </div>
      </div>

      {/* ML Evaluation KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="fintech-card rounded-xl p-4 space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            ROC-AUC Score
          </span>
          <span className="text-xl font-bold font-mono text-emerald-400">
            {(ml.roc_auc * 100).toFixed(2)}%
          </span>
        </div>
        <div className="fintech-card rounded-xl p-4 space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Accuracy
          </span>
          <span className="text-xl font-bold font-mono text-slate-100">
            {(ml.accuracy * 100).toFixed(2)}%
          </span>
        </div>
        <div className="fintech-card rounded-xl p-4 space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Precision (Recov.)
          </span>
          <span className="text-xl font-bold font-mono text-slate-100">
            {(ml.precision_recoverable * 100).toFixed(2)}%
          </span>
        </div>
        <div className="fintech-card rounded-xl p-4 space-y-1">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Recall (Recov.)
          </span>
          <span className="text-xl font-bold font-mono text-slate-100">
            {(ml.recall_recoverable * 100).toFixed(2)}%
          </span>
        </div>
        <div className="fintech-card rounded-xl p-4 space-y-1 col-span-2 sm:col-span-1">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            F1-Score
          </span>
          <span className="text-xl font-bold font-mono text-indigo-400">
            {(ml.f1_recoverable * 100).toFixed(2)}%
          </span>
        </div>
      </div>

      {/* Model Benchmark & Confusion Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Confusion Matrix */}
        <div className="fintech-card rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Brain className="w-4 h-4 text-brand-400" />
              Evaluation Confusion Matrix (N = {ml.total_test_samples})
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2 text-center text-xs">
            <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-500/30 space-y-1">
              <span className="text-[10px] font-bold uppercase text-emerald-400">True Positive (TP)</span>
              <span className="text-2xl font-bold font-mono text-slate-100 block">{cm.true_positive}</span>
              <span className="text-[10px] text-slate-400">Correctly Predicted Recoverable</span>
            </div>
            <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">False Positive (FP)</span>
              <span className="text-2xl font-bold font-mono text-amber-400 block">{cm.false_positive}</span>
              <span className="text-[10px] text-slate-400">Incorrectly Flagged Recoverable</span>
            </div>
            <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">False Negative (FN)</span>
              <span className="text-2xl font-bold font-mono text-rose-400 block">{cm.false_negative}</span>
              <span className="text-[10px] text-slate-400">Missed Recoverable Cases</span>
            </div>
            <div className="p-4 rounded-lg bg-indigo-950/20 border border-indigo-500/30 space-y-1">
              <span className="text-[10px] font-bold uppercase text-indigo-400">True Negative (TN)</span>
              <span className="text-2xl font-bold font-mono text-slate-100 block">{cm.true_negative}</span>
              <span className="text-[10px] text-slate-400">Correctly Flagged Non-Recoverable</span>
            </div>
          </div>
        </div>

        {/* Top Feature Importance Chart */}
        <div className="fintech-card rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-400" />
              Top Predictive Feature Importances
            </h3>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topFeatures.slice(0, 5)} layout="vertical" margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                <XAxis type="number" stroke="#64748b" fontSize={10} />
                <YAxis dataKey="feature" type="category" stroke="#94a3b8" fontSize={10} width={90} tickFormatter={(v) => v.replace('failure_reason_', '')} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }} />
                <Bar dataKey="importance" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recovery Strategy ROI Table */}
      <div className="fintech-card rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Autonomous Strategy ROI Breakdown
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Efficiency and revenue yields across specific automated recovery tactics.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">Recovery Strategy</th>
                <th className="py-3 px-3">Invocations</th>
                <th className="py-3 px-3">Successes</th>
                <th className="py-3 px-3">Conversion Rate</th>
                <th className="py-3 px-3">Revenue Recovered</th>
                <th className="py-3 px-3">Avg. Resolution Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {data?.strategy_roi.map((s, i) => (
                <tr key={i} className="hover:bg-slate-800/40">
                  <td className="py-3 px-3 font-sans font-semibold text-indigo-300">
                    {s.strategy.replace(/_/g, ' ')}
                  </td>
                  <td className="py-3 px-3 text-slate-300">{s.attempted_count}</td>
                  <td className="py-3 px-3 text-emerald-400 font-bold">{s.success_count}</td>
                  <td className="py-3 px-3 font-bold text-slate-100">{s.success_rate}%</td>
                  <td className="py-3 px-3 text-emerald-400 font-bold">
                    {formatCurrency(s.revenue_recovered)}
                  </td>
                  <td className="py-3 px-3 text-slate-400">{s.avg_recovery_time_mins} mins</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
