import React, { useEffect, useState } from 'react';
import { Users, RefreshCw, ArrowRight, ShieldCheck, CreditCard } from 'lucide-react';
import { fetchCustomers } from '../api/customers';
import { Customer } from '../types/customer';
import { formatCurrency, formatDate } from '../utils/formatters';

export const CustomersPage: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const data = await fetchCustomers(1, 50);
      setCustomers(data);
    } catch (err) {
      console.error('Failed to load customers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">Customer Payment Profiles</h1>
          <p className="text-xs text-slate-400 mt-1">
            Historical transaction fidelity, customer spend tiers, and payment reliability metrics.
          </p>
        </div>
        <button
          onClick={loadCustomers}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Customers Table */}
      <div className="fintech-card rounded-xl p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">Customer ID</th>
                <th className="py-3 px-3">Name</th>
                <th className="py-3 px-3">Contact Email</th>
                <th className="py-3 px-3">Tier</th>
                <th className="py-3 px-3">Total TXNs</th>
                <th className="py-3 px-3">Success Rate</th>
                <th className="py-3 px-3">Avg. Spend</th>
                <th className="py-3 px-3">Last Payment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto text-brand-400 mb-2" />
                    Loading customer profiles...
                  </td>
                </tr>
              ) : (
                customers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-mono font-semibold text-indigo-300">{cust.id}</td>
                    <td className="py-3 px-3 font-medium text-slate-200">{cust.name}</td>
                    <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">{cust.email}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        cust.tier === 'VIP'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : cust.tier === 'PREMIUM'
                          ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {cust.tier}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {cust.successful_transactions} / {cust.total_transactions}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-emerald-400">
                        {((cust.historical_success_rate || 1) * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-200">
                      {formatCurrency(cust.avg_transaction_amount)}
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {formatDate(cust.last_payment_at)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
