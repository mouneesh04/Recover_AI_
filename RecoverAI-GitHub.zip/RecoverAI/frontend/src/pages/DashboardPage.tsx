import React, { useEffect, useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  ShieldAlert,
  ArrowUpRight,
  RefreshCw,
} from 'lucide-react';
import { fetchDashboardMetrics } from '../api/dashboard';
import { fetchTransactions } from '../api/transactions';
import { DashboardMetricsResponse } from '../types/dashboard';
import { Transaction } from '../types/transaction';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { ProbabilityMeter } from '../components/common/ProbabilityMeter';
import { DemoBanner } from '../components/common/DemoBanner';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useNavigate } from 'react-router-dom';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const [data, setData] = useState<DashboardMetricsResponse | null>(null);
  const [recentTxns, setRecentTxns] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      setLoading(true);
      const [dashRes, txnRes] = await Promise.all([
        fetchDashboardMetrics(),
        fetchTransactions({ page: 1, page_size: 8 }),
      ]);
      setData(dashRes);
      setRecentTxns(txnRes.items);
    } catch (err) {
      console.error('Failed to fetch dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center h-96">
        <RefreshCw className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  const m = data?.metrics;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <DemoBanner onRecoverSuccess={loadData} />

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Revenue Recovered"
          value={formatCurrency(m?.revenue_recovered || 0)}
          subtitle={`${m?.recovered_count || 0} payments recaptured`}
          change="+18.4% this week"
          isPositive={true}
          icon={TrendingUp}
          iconColor="text-emerald-400"
          iconBg="bg-emerald-500/10"
        />
        <MetricCard
          title="Revenue at Risk"
          value={formatCurrency(m?.revenue_at_risk || 0)}
          subtitle={`From ${m?.failed_transactions || 0} failed payments`}
          icon={DollarSign}
          iconColor="text-amber-400"
          iconBg="bg-amber-500/10"
        />
        <MetricCard
          title="Autonomous Recovery Rate"
          value={`${m?.recovery_rate_pct || 0}%`}
          subtitle="Target: 60%+ recovery"
          change="+6.2% vs manual"
          isPositive={true}
          icon={CheckCircle}
          iconColor="text-brand-400"
          iconBg="bg-brand-500/10"
        />
        <MetricCard
          title="Human Review Queue"
          value={m?.human_review_cases || 0}
          subtitle="High value (> ₹25k) & policy alerts"
          icon={ShieldAlert}
          iconColor="text-indigo-400"
          iconBg="bg-indigo-500/10"
        />
      </div>

      {/* Timeseries Revenue Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Revenue Trend Area Chart */}
        <div className="fintech-card rounded-xl p-6 lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
                Recovered Revenue vs. Revenue at Risk
              </h3>
              <p className="text-xs text-slate-400">7-day continuous recovery progression</p>
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.timeseries || []} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="recoveredGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `₹${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, '']}
                />
                <Area
                  type="monotone"
                  dataKey="revenue_recovered"
                  name="Revenue Recovered"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#recoveredGrad)"
                />
                <Area
                  type="monotone"
                  dataKey="revenue_at_risk"
                  name="Revenue at Risk"
                  stroke="#f59e0b"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  fillOpacity={1}
                  fill="url(#riskGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Failure Reasons Breakdown */}
        <div className="fintech-card rounded-xl p-6 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Top Failure Categories
            </h3>
            <p className="text-xs text-slate-400">Classified by upstream banking response</p>
          </div>

          <div className="space-y-3 pt-2">
            {data?.failure_reasons.slice(0, 5).map((f, i) => (
              <div key={i} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium">{f.name.replace(/_/g, ' ')}</span>
                  <span className="text-slate-400 font-mono">
                    {f.count} ({f.percentage}%)
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-500 rounded-full"
                    style={{ width: `${f.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Failed & Recovered Transactions Table */}
      <div className="fintech-card rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Recent Failed Payment Ingestions
            </h3>
            <p className="text-xs text-slate-400">Live stream of intercepted failed transactions</p>
          </div>
          <button
            onClick={() => navigate('/transactions')}
            className="text-xs font-semibold text-brand-400 hover:text-brand-300 flex items-center gap-1"
          >
            View All Transactions <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">TXN ID</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3">Amount</th>
                <th className="py-3 px-3">Payment Method</th>
                <th className="py-3 px-3">Failure Reason</th>
                <th className="py-3 px-3">Recovery Confidence</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentTxns.map((txn) => (
                <tr
                  key={txn.id}
                  onClick={() => navigate(`/transactions/${txn.id}`)}
                  className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-3 font-mono font-semibold text-indigo-300">{txn.id}</td>
                  <td className="py-3 px-3 text-slate-200">{txn.customer_name || txn.customer_id}</td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-100">
                    {formatCurrency(txn.amount, txn.currency)}
                  </td>
                  <td className="py-3 px-3 text-slate-300">{txn.payment_method}</td>
                  <td className="py-3 px-3 text-slate-300 font-mono text-[11px]">
                    {txn.failure_reason || '—'}
                  </td>
                  <td className="py-3 px-3">
                    <ProbabilityMeter probability={txn.recovery_probability} size="sm" />
                  </td>
                  <td className="py-3 px-3">
                    <StatusBadge status={txn.status} />
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/transactions/${txn.id}`);
                      }}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-slate-700"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
