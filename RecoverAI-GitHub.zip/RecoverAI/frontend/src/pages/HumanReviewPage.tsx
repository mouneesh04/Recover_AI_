import React, { useEffect, useState } from 'react';
import { ShieldAlert, CheckCircle2, XCircle, RefreshCw, AlertTriangle, User, DollarSign } from 'lucide-react';
import { fetchHumanReviewQueue, approveRecovery, rejectRecovery } from '../api/recovery';
import { HumanReviewItem } from '../types/recovery';
import { ProbabilityMeter } from '../components/common/ProbabilityMeter';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useNavigate } from 'react-router-dom';

export const HumanReviewPage: React.FC = () => {
  const [queue, setQueue] = useState<HumanReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const navigate = useNavigate();

  const loadQueue = async () => {
    try {
      setLoading(true);
      const data = await fetchHumanReviewQueue();
      setQueue(data);
    } catch (err) {
      console.error('Failed to load review queue:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQueue();
  }, []);

  const handleApprove = async (transactionId: string) => {
    try {
      setProcessingId(transactionId);
      const res = await approveRecovery(transactionId);
      setNotification(`Approved recovery for ${transactionId}. Outcome: ${res.execution_result?.outcome || 'SUCCESS'}`);
      await loadQueue();
    } catch (err) {
      console.error('Failed to approve:', err);
      setNotification('Approval action encountered an error.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (transactionId: string) => {
    try {
      setProcessingId(transactionId);
      await rejectRecovery(transactionId, 'Rejected by merchant compliance operator.');
      setNotification(`Rejected recovery for ${transactionId}. Marked as NON_RECOVERABLE.`);
      await loadQueue();
    } catch (err) {
      console.error('Failed to reject:', err);
      setNotification('Rejection action encountered an error.');
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">Human-in-the-Loop Review Queue</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            High-value transactions and policy escalations requiring manual merchant approval before recovery.
          </p>
        </div>
        <button
          onClick={loadQueue}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {notification && (
        <div className="p-3 rounded-lg bg-indigo-950/60 border border-indigo-500/30 text-indigo-200 text-xs flex items-center justify-between">
          <span>{notification}</span>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Queue Items */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 text-brand-400 animate-spin" />
        </div>
      ) : queue.length === 0 ? (
        <div className="fintech-card rounded-xl p-12 text-center space-y-3">
          <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto opacity-80" />
          <h3 className="text-base font-semibold text-slate-200">Human Review Queue is Empty</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            All high-value payments have been resolved. The Autonomous Recovery Agent is handling normal low-risk transactions automatically.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {queue.map((item) => (
            <div
              key={item.id}
              className="fintech-card rounded-xl p-6 border-amber-500/30 bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/10 space-y-4"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <span className="text-base font-bold font-mono text-slate-100">{item.id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      MANUAL REVIEW
                    </span>
                    <span className="text-xs text-slate-400">{formatDate(item.created_at)}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-300">
                    <span className="flex items-center gap-1 font-medium">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {item.customer_name} ({item.customer_tier})
                    </span>
                    <span className="text-slate-400">•</span>
                    <span>Method: <strong className="text-slate-200">{item.payment_method}</strong></span>
                    <span className="text-slate-400">•</span>
                    <span>Reason: <strong className="text-rose-400">{item.failure_reason}</strong></span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-2xl font-bold font-mono text-slate-100">
                    {formatCurrency(item.amount, item.currency)}
                  </span>
                  <span className="block text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                    Amount at Risk
                  </span>
                </div>
              </div>

              {/* Escalation Rationale & Factors */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Escalation Trigger Rationale:
                  </span>
                  <p className="text-slate-300 leading-relaxed">{item.escalation_reason}</p>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
                  <ProbabilityMeter probability={item.recovery_probability} size="md" />
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/80">
                    <span className="text-slate-400">Proposed Strategy:</span>
                    <span className="font-semibold text-indigo-300 font-mono">
                      {item.recommended_strategy.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => navigate(`/transactions/${item.id}`)}
                  className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700"
                >
                  Full Transaction Context
                </button>
                <button
                  onClick={() => handleReject(item.id)}
                  disabled={processingId === item.id}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors"
                >
                  <XCircle className="w-4 h-4" />
                  Reject Recovery
                </button>
                <button
                  onClick={() => handleApprove(item.id)}
                  disabled={processingId === item.id}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition-colors"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Approve Recovery Action
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
