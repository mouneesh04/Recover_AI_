import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  RefreshCw,
  Zap,
  Send,
  ShieldAlert,
  User,
  CreditCard,
  Clock,
  Server,
  Activity,
  CheckCircle,
} from 'lucide-react';
import {
  fetchTransactionDetail,
  fetchTransactionTimeline,
  analyzeTransaction,
  recoverTransaction,
  retryTransaction,
  remindTransaction,
  escalateTransaction,
} from '../api/transactions';
import { StatusBadge } from '../components/common/StatusBadge';
import { RecoveryTimeline } from '../components/transaction/RecoveryTimeline';
import { AIInsightCard } from '../components/transaction/AIInsightCard';
import { formatCurrency, formatDate } from '../utils/formatters';

export const TransactionDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [txnData, setTxnData] = useState<any>(null);
  const [timeline, setTimeline] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isExecuting, setIsExecuting] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const loadDetails = async () => {
    if (!id) return;
    try {
      setLoading(true);
      const [detailRes, timelineRes] = await Promise.all([
        fetchTransactionDetail(id),
        fetchTransactionTimeline(id),
      ]);
      setTxnData(detailRes);
      setTimeline(timelineRes);
    } catch (err) {
      console.error('Failed to load transaction details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDetails();
  }, [id]);

  const handleRunAutonomousRecovery = async () => {
    if (!id) return;
    try {
      setIsExecuting(true);
      setActionMessage('Autonomous Agent is evaluating and executing recovery strategy...');
      const res = await recoverTransaction(id);
      setActionMessage(`Agent executed: ${res.final_outcome || 'Workflow completed'}.`);
      await loadDetails();
    } catch (err) {
      console.error('Recovery failed:', err);
      setActionMessage('Recovery action encountered an error.');
    } finally {
      setIsExecuting(false);
    }
  };

  const handleManualRetry = async () => {
    if (!id) return;
    try {
      setIsExecuting(true);
      await retryTransaction(id);
      await loadDetails();
    } catch (err) {
      console.error('Retry failed:', err);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSendReminder = async () => {
    if (!id) return;
    try {
      setIsExecuting(true);
      await remindTransaction(id);
      await loadDetails();
    } catch (err) {
      console.error('Reminder failed:', err);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleEscalate = async () => {
    if (!id) return;
    try {
      setIsExecuting(true);
      await escalateTransaction(id, 'Merchant requested manual escalation.');
      await loadDetails();
    } catch (err) {
      console.error('Escalation failed:', err);
    } finally {
      setIsExecuting(false);
    }
  };

  if (loading && !txnData) {
    return (
      <div className="flex items-center justify-center h-96">
        <RefreshCw className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  const txn = txnData?.transaction;
  const cust = txnData?.customer;
  const dec = txnData?.latest_decision;

  return (
    <div className="space-y-6">
      {/* Navigation & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/transactions')}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold text-slate-100 font-mono tracking-tight">{txn?.id}</h1>
              <StatusBadge status={txn?.status} />
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Ingested at {formatDate(txn?.created_at)} • Attempt #{txn?.retry_count + 1} of {txn?.max_retries}
            </p>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {txn?.status !== 'RECOVERED' && (
            <>
              <button
                onClick={handleRunAutonomousRecovery}
                disabled={isExecuting}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md transition-colors"
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                <span>Run Autonomous Agent</span>
              </button>
              <button
                onClick={handleManualRetry}
                disabled={isExecuting}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Manual Retry</span>
              </button>
              <button
                onClick={handleSendReminder}
                disabled={isExecuting}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Reminder</span>
              </button>
              <button
                onClick={handleEscalate}
                disabled={isExecuting}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-amber-400 text-xs font-medium border border-slate-700 transition-colors"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Escalate</span>
              </button>
            </>
          )}
        </div>
      </div>

      {actionMessage && (
        <div className="p-3 rounded-lg bg-indigo-950/60 border border-indigo-500/30 text-indigo-200 text-xs flex items-center gap-2">
          <Activity className="w-4 h-4 text-indigo-400 shrink-0 animate-pulse" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Main Grid: Details + AI Explainability */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Overview & Dynamic Timeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Metadata Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="fintech-card rounded-xl p-4 space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Amount
              </span>
              <span className="text-xl font-bold font-mono text-slate-100">
                {formatCurrency(txn?.amount, txn?.currency)}
              </span>
            </div>
            <div className="fintech-card rounded-xl p-4 space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Payment Method
              </span>
              <span className="text-sm font-semibold text-indigo-300">{txn?.payment_method}</span>
            </div>
            <div className="fintech-card rounded-xl p-4 space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Failure Reason
              </span>
              <span className="text-xs font-mono font-semibold text-rose-400 block truncate">
                {txn?.failure_reason || 'UNKNOWN'}
              </span>
            </div>
            <div className="fintech-card rounded-xl p-4 space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Bank Latency
              </span>
              <span className="text-sm font-mono text-slate-200">{txn?.bank_response_time_ms || 750} ms</span>
            </div>
          </div>

          {/* Dynamic Recovery Timeline */}
          <RecoveryTimeline events={timeline?.events || []} currentStatus={txn?.status} />
        </div>

        {/* Right 1 Col: Customer Profile & AI Insight Panel */}
        <div className="space-y-6">
          {/* Customer Profile Card */}
          <div className="fintech-card rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-brand-400" />
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Customer Profile
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {cust?.tier || 'STANDARD'}
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Name</span>
                <span className="text-slate-200 font-medium">{cust?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Email</span>
                <span className="text-slate-300 font-mono text-[11px]">{cust?.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Historical Success Rate</span>
                <span className="text-emerald-400 font-semibold font-mono">
                  {((cust?.historical_success_rate || 1) * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Past Transactions</span>
                <span className="text-slate-200 font-mono">
                  {cust?.successful_transactions}/{cust?.total_transactions} successful
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Avg. Ticket Size</span>
                <span className="text-slate-200 font-mono">
                  {formatCurrency(cust?.avg_transaction_amount || 0)}
                </span>
              </div>
            </div>
          </div>

          {/* AI Decision & Explainability Card */}
          <AIInsightCard
            recoveryProbability={txn?.recovery_probability || 0.5}
            riskLevel={txn?.risk_level || 'LOW'}
            recommendedStrategy={txn?.recommended_strategy || 'RETRY_LATER'}
            explanationSummary={dec?.reasoning_text}
            keyFactors={dec?.factors || []}
            onTriggerRecovery={handleRunAutonomousRecovery}
            isExecuting={isExecuting}
            currentStatus={txn?.status}
          />
        </div>
      </div>
    </div>
  );
};
