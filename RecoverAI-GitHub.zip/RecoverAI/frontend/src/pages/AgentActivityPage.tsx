import React, { useEffect, useState } from 'react';
import { Bot, RefreshCw, Activity, CheckCircle2, ShieldAlert, Send, Zap, Sparkles } from 'lucide-react';
import { fetchAgentActivity } from '../api/agent';
import { AgentActivityEvent } from '../types/agent';
import { formatCurrency, formatTime, formatDate } from '../utils/formatters';
import { useNavigate } from 'react-router-dom';

export const AgentActivityPage: React.FC = () => {
  const [events, setEvents] = useState<AgentActivityEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const navigate = useNavigate();

  const loadActivity = async () => {
    try {
      const data = await fetchAgentActivity(40);
      setEvents(data);
    } catch (err) {
      console.error('Failed to load agent activity:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivity();
  }, []);

  // Live polling for real-time agent stream demo
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      loadActivity();
    }, 4000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'PAYMENT_RECOVERED':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'ESCALATED':
        return <ShieldAlert className="w-4 h-4 text-amber-400" />;
      case 'REMINDER_SENT':
        return <Send className="w-4 h-4 text-blue-400" />;
      case 'RETRY_EXECUTED':
        return <Zap className="w-4 h-4 text-brand-400" />;
      default:
        return <Activity className="w-4 h-4 text-indigo-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-brand-400" />
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">
              RecoverAI Agent Activity Stream
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Live autonomous event ticker recording ML predictions, policy guard decisions, and revenue captures.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-brand-500 focus:ring-0"
            />
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
              Live Feed Active
            </span>
          </label>

          <button
            onClick={loadActivity}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Live Stream Event Cards */}
      <div className="fintech-card rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Agent Actions ({events.length} events)
          </span>
          <span className="text-[11px] font-mono text-slate-400">Timestamp (IST)</span>
        </div>

        <div className="space-y-2.5">
          {events.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No recent agent events. Trigger a recovery to observe activity.
            </div>
          ) : (
            events.map((evt) => (
              <div
                key={evt.id}
                onClick={() => evt.transaction_id && evt.transaction_id !== 'SYSTEM' && navigate(`/transactions/${evt.transaction_id}`)}
                className="flex items-start justify-between p-3.5 rounded-lg bg-slate-900/80 border border-slate-800/80 hover:border-indigo-500/40 hover:bg-slate-850/90 cursor-pointer transition-all duration-150 gap-4"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-slate-800/90 border border-slate-700/60 shrink-0 mt-0.5">
                    {getEventIcon(evt.event_type)}
                  </div>
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-100">{evt.headline}</span>
                      {evt.transaction_id && (
                        <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                          {evt.transaction_id}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed truncate max-w-2xl">{evt.detail}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] font-mono text-slate-400 block">{formatTime(evt.timestamp)}</span>
                  <span className="text-[10px] text-slate-500">{formatDate(evt.timestamp)}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
