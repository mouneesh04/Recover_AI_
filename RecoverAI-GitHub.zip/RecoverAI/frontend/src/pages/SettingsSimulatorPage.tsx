import React, { useState } from 'react';
import { Sliders, RefreshCw, ShieldCheck, Database, Play, CheckCircle2, AlertTriangle } from 'lucide-react';
import { seedDemoScenario, resetDatabase, updateSimulatorLatency } from '../api/simulator';

export const SettingsSimulatorPage: React.FC = () => {
  const [latency, setLatency] = useState(150);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLatencyChange = async (newVal: number) => {
    setLatency(newVal);
    try {
      await updateSimulatorLatency(newVal);
      setMessage(`Simulator latency updated to ${newVal}ms.`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleReSeedDemo = async () => {
    try {
      setLoading(true);
      await seedDemoScenario();
      setMessage('Demo transaction TXN-DEMO-001 has been initialized in FAILED state.');
    } catch (err) {
      console.error(err);
      setMessage('Failed to initialize demo scenario.');
    } finally {
      setLoading(false);
    }
  };

  const handleFullReset = async () => {
    if (!window.confirm('Are you sure you want to reset all transactions and metrics?')) return;
    try {
      setLoading(true);
      await resetDatabase();
      setMessage('Database reset and seeded with 250 fresh transactions.');
    } catch (err) {
      console.error(err);
      setMessage('Database reset failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Sliders className="w-5 h-5 text-brand-400" />
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Simulator & Safety Settings
          </h1>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Configure payment gateway mock parameters, reset demonstration state, and inspect guardrails.
        </p>
      </div>

      {message && (
        <div className="p-3.5 rounded-lg bg-indigo-950/70 border border-indigo-500/30 text-indigo-200 text-xs flex items-center justify-between">
          <span>{message}</span>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Simulator Controls */}
      <div className="fintech-card rounded-xl p-6 space-y-6">
        <div className="border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Payment Gateway Simulator Configuration
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Controls synthetic banking API latency and gateway mock behavior.
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300 font-medium">Gateway Network Latency</span>
            <span className="font-mono font-bold text-indigo-300">{latency} ms</span>
          </div>
          <input
            type="range"
            min={30}
            max={600}
            step={10}
            value={latency}
            onChange={(e) => handleLatencyChange(Number(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-brand-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>Fast (30ms)</span>
            <span>Realistic (150ms)</span>
            <span>Slow Upstream (600ms)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <button
            onClick={handleReSeedDemo}
            disabled={loading}
            className="flex items-center justify-center gap-2 p-3 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-colors"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Reset Demo Scenario (TXN-DEMO-001)</span>
          </button>

          <button
            onClick={handleFullReset}
            disabled={loading}
            className="flex items-center justify-center gap-2 p-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition-colors"
          >
            <Database className="w-4 h-4" />
            <span>Full Database Re-seed (250 TXNs)</span>
          </button>
        </div>
      </div>

      {/* Safety Guardrails Overview */}
      <div className="fintech-card rounded-xl p-6 space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Active Autonomous Safety Guardrails
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Hard system constraints enforced before any automated payment tool execution.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400">Max Retry Attempts</span>
            <span className="text-lg font-bold font-mono text-slate-100 block">3 Attempts</span>
            <span className="text-[10px] text-slate-500">Escalates after 3rd failure</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400">High-Value Threshold</span>
            <span className="text-lg font-bold font-mono text-slate-100 block">₹25,000</span>
            <span className="text-[10px] text-slate-500">Requires human sign-off</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400">Min Confidence Floor</span>
            <span className="text-lg font-bold font-mono text-slate-100 block">35%</span>
            <span className="text-[10px] text-slate-500">Blocks low-probability retries</span>
          </div>
        </div>
      </div>
    </div>
  );
};
