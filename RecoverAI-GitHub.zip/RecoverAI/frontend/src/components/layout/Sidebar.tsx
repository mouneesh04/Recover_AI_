import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  ReceiptText,
  ShieldAlert,
  Users,
  BarChart3,
  Bot,
  Sliders,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

const NAV_ITEMS = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Failed Payments', path: '/transactions', icon: ReceiptText },
  { name: 'Human Review Queue', path: '/recovery', icon: ShieldAlert },
  { name: 'Customer Profiles', path: '/customers', icon: Users },
  { name: 'ML & Revenue Analytics', path: '/analytics', icon: BarChart3 },
  { name: 'Live Agent Activity', path: '/agent-activity', icon: Bot },
  { name: 'Simulator & Settings', path: '/settings', icon: Sliders },
];

export const Sidebar: React.FC = () => {
  return (
    <aside className="w-64 bg-[#0d1322] border-r border-slate-800/80 flex flex-col h-screen shrink-0 select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center px-6 border-b border-slate-800/80 gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-brand-500/20">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <span className="text-base font-bold text-slate-100 tracking-tight flex items-center gap-1.5">
            Recover<span className="text-brand-400">AI</span>
          </span>
          <span className="block text-[10px] font-medium text-slate-400 -mt-0.5">
            Autonomous Recovery Agent
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2">
          <span className="text-[10px] font-bold tracking-wider uppercase text-slate-400">
            Platform Views
          </span>
        </div>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-brand-600/15 text-brand-300 border border-brand-500/30 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* System Status Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-medium">Agent Engine</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Autonomous
            </span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Model: XGBoost v2</span>
            <span>AUC: 0.996</span>
          </div>
        </div>
        <div className="mt-3 text-[10px] text-center text-slate-400">
          Demo Environment • No Real Money
        </div>
      </div>
    </aside>
  );
};
