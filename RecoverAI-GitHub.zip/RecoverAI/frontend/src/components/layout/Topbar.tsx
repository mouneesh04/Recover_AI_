import React from 'react';
import { ShieldCheck, Bell, RefreshCw, Cpu } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface TopbarProps {
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const Topbar: React.FC<TopbarProps> = ({ onRefresh, isRefreshing = false }) => {
  const navigate = useNavigate();

  return (
    <header className="h-16 border-b border-slate-800/80 bg-[#0d1322]/80 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Safety Guardrails Active (Cap: ₹25,000 | Max 3 Retries)</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Refresh Data</span>
          </button>
        )}

        <button
          onClick={() => navigate('/agent-activity')}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/25 text-xs font-medium transition-colors"
        >
          <Cpu className="w-3.5 h-3.5 text-indigo-400" />
          <span>Live Agent Stream</span>
        </button>
      </div>
    </header>
  );
};
