import React from 'react';

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  const normalized = (status || '').toUpperCase();

  let bgClass = 'bg-slate-800/80 text-slate-300 border-slate-700';
  let dotClass = 'bg-slate-400';

  if (normalized === 'SUCCESS' || normalized === 'RECOVERED') {
    bgClass = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
    dotClass = 'bg-emerald-400';
  } else if (normalized === 'FAILED' || normalized === 'NON_RECOVERABLE') {
    bgClass = 'bg-rose-500/10 text-rose-400 border-rose-500/30';
    dotClass = 'bg-rose-400';
  } else if (normalized === 'RECOVERING' || normalized === 'PENDING') {
    bgClass = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    dotClass = 'bg-amber-400 animate-pulse';
  } else if (normalized === 'MANUAL_REVIEW' || normalized === 'ESCALATED') {
    bgClass = 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30';
    dotClass = 'bg-indigo-400';
  }

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${bgClass} ${className}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotClass}`}></span>
      {normalized.replace(/_/g, ' ')}
    </span>
  );
};
