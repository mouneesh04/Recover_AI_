import React from 'react';

interface ProbabilityMeterProps {
  probability: number | undefined;
  size?: 'sm' | 'md' | 'lg';
}

export const ProbabilityMeter: React.FC<ProbabilityMeterProps> = ({ probability = 0, size = 'md' }) => {
  const pct = Math.round(probability * 100);

  let barColor = 'bg-rose-500';
  let textColor = 'text-rose-400';
  let label = 'Low';

  if (pct >= 75) {
    barColor = 'bg-emerald-500';
    textColor = 'text-emerald-400';
    label = 'High';
  } else if (pct >= 45) {
    barColor = 'bg-amber-500';
    textColor = 'text-amber-400';
    label = 'Medium';
  }

  if (size === 'sm') {
    return (
      <div className="flex items-center gap-2">
        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div className={`h-full ${barColor} rounded-full`} style={{ width: `${pct}%` }} />
        </div>
        <span className={`text-xs font-semibold ${textColor}`}>{pct}%</span>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-400 font-medium">Recovery Confidence</span>
        <span className={`font-bold ${textColor}`}>{pct}% ({label})</span>
      </div>
      <div className="w-full h-2.5 bg-slate-800/90 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
        <div
          className={`h-full ${barColor} rounded-full transition-all duration-500 shadow-sm`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};
