import React, { useState } from 'react';
import { Play, Sparkles, CheckCircle2, ArrowRight, RefreshCw } from 'lucide-react';
import { seedDemoScenario } from '../../api/simulator';
import { recoverTransaction } from '../../api/transactions';
import { useNavigate } from 'react-router-dom';

interface DemoBannerProps {
  onRecoverSuccess?: () => void;
}

export const DemoBanner: React.FC<DemoBannerProps> = ({ onRecoverSuccess }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [demoState, setDemoState] = useState<'IDLE' | 'SEEDED' | 'RECOVERED'>('IDLE');
  const navigate = useNavigate();

  const handleRunDemo = async () => {
    try {
      setIsRunning(true);
      // 1. Seed demo
      await seedDemoScenario();
      setDemoState('SEEDED');
      
      // 2. Wait 400ms for realistic presentation pacing then trigger autonomous recovery
      await new Promise(r => setTimeout(r, 600));
      await recoverTransaction('TXN-DEMO-001');
      setDemoState('RECOVERED');
      
      if (onRecoverSuccess) {
        onRecoverSuccess();
      }
    } catch (err) {
      console.error('Demo run failed:', err);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/80 via-slate-900 to-slate-950 p-5 shadow-lg">
      <div className="absolute top-0 right-0 -mr-8 -mt-8 w-40 h-40 bg-brand-500/10 rounded-full blur-2xl pointer-events-none" />
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
        <div className="flex items-start gap-3.5">
          <div className="p-2.5 rounded-lg bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 mt-0.5">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wide">
                Interactive Evaluator Demo Scenario
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                TXN-DEMO-001 (₹8,999)
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Demonstrates end-to-end autonomous recovery: <span className="text-slate-300 font-medium">Bank Timeout Intercept → ML Recoverability Prediction (91%) → Autonomous RETRY_LATER Execution → Revenue Captured</span>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {demoState === 'RECOVERED' ? (
            <button
              onClick={() => navigate('/transactions/TXN-DEMO-001')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition-all duration-150"
            >
              <CheckCircle2 className="w-4 h-4" />
              View Recovered TXN Timeline
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handleRunDemo}
              disabled={isRunning}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md transition-all duration-150 hover:shadow-brand-500/25"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Autonomous Agent Running...
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Run Autonomous Demo
                </>
              )}
            </button>
          )}

          <button
            onClick={async () => {
              await seedDemoScenario();
              setDemoState('SEEDED');
              navigate('/transactions/TXN-DEMO-001');
            }}
            className="px-3 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
          >
            Inspect Demo TXN
          </button>
        </div>
      </div>
    </div>
  );
};
