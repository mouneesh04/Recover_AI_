import React from 'react';
import { TimelineEvent } from '../../types/transaction';
import { formatDate } from '../../utils/formatters';
import {
  AlertCircle,
  Brain,
  CheckCircle2,
  Clock,
  Send,
  Zap,
  ShieldAlert,
  ArrowDown,
} from 'lucide-react';

interface RecoveryTimelineProps {
  events: TimelineEvent[];
  currentStatus: string;
}

export const RecoveryTimeline: React.FC<RecoveryTimelineProps> = ({ events, currentStatus }) => {
  const getIcon = (type: string, status: string) => {
    switch (type) {
      case 'FAILED':
        return <AlertCircle className="w-4 h-4 text-rose-400" />;
      case 'ANALYZED':
        return <Brain className="w-4 h-4 text-indigo-400" />;
      case 'ACTION_EXECUTED':
        return status === 'SUCCESS' ? (
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        ) : (
          <Zap className="w-4 h-4 text-amber-400" />
        );
      case 'REMINDER_SENT':
        return <Send className="w-4 h-4 text-blue-400" />;
      case 'ESCALATED':
        return <ShieldAlert className="w-4 h-4 text-amber-400" />;
      case 'RECOVERED':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getBorderColor = (status: string) => {
    switch (status) {
      case 'SUCCESS':
        return 'border-emerald-500/40 bg-emerald-950/20';
      case 'FAILED':
        return 'border-rose-500/40 bg-rose-950/20';
      case 'PENDING':
        return 'border-amber-500/40 bg-amber-950/20';
      default:
        return 'border-slate-700 bg-slate-850';
    }
  };

  return (
    <div className="fintech-card rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <Zap className="w-4 h-4 text-brand-400" />
            Autonomous Recovery Lifecycle
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time chronological trace of AI observation, reasoning, and tool execution.
          </p>
        </div>
      </div>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
        {events.map((evt, idx) => (
          <div key={idx} className="relative group">
            {/* Step Node Icon */}
            <div
              className={`absolute -left-6 top-0.5 w-6 h-6 rounded-full border flex items-center justify-center bg-[#0d1322] shadow-sm z-10 ${getBorderColor(
                evt.status
              )}`}
            >
              {getIcon(evt.type, evt.status)}
            </div>

            {/* Content Box */}
            <div className="bg-slate-900/90 rounded-lg border border-slate-800 p-4 space-y-1.5 hover:border-slate-700 transition-colors">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-200">{evt.title}</span>
                <span className="text-[11px] font-mono text-slate-400">{formatDate(evt.timestamp)}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{evt.description}</p>

              {evt.metadata && (
                <div className="pt-2 mt-2 border-t border-slate-800/80 flex flex-wrap gap-2 text-[11px] font-mono">
                  {Object.entries(evt.metadata).map(([k, v]) => (
                    <span
                      key={k}
                      className="px-2 py-0.5 rounded bg-slate-800/80 text-slate-400 border border-slate-700/60"
                    >
                      <strong className="text-slate-300 font-semibold">{k}:</strong> {String(v)}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
