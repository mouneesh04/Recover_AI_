import api from './client';
import { Customer, CustomerDetail } from '../types/customer';
import { AnalyticsResponse } from '../types/analytics';

export async function fetchCustomers(page: number = 1, page_size: number = 20): Promise<Customer[]> {
  const res = await api.get('/customers', { params: { page, page_size } });
  return res.data;
}

export async function fetchCustomerDetail(id: string): Promise<CustomerDetail> {
  const res = await api.get(`/customers/${id}`);
  return res.data;
}

export async function fetchAnalytics(): Promise<AnalyticsResponse> {
  const res = await api.get('/analytics');
  return res.data;
}

export async function seedDemoScenario(): Promise<any> {
  const res = await api.post('/simulator/seed-demo');
  return res.data;
}

export async function resetDatabase(): Promise<any> {
  const res = await api.post('/simulator/reset');
  return res.data;
}

export async function updateSimulatorLatency(latencyMs: number): Promise<any> {
  const res = await api.post('/simulator/config', null, { params: { latency_ms: latencyMs } });
  return res.data;
}
