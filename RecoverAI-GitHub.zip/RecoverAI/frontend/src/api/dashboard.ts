import api from './client';
import { DashboardMetricsResponse } from '../types/dashboard';

export async function fetchDashboardMetrics(): Promise<DashboardMetricsResponse> {
  const res = await api.get('/dashboard/metrics');
  return res.data;
}
