import api from './client';
import { AgentActivityEvent } from '../types/agent';

export async function fetchAgentActivity(limit: number = 30): Promise<AgentActivityEvent[]> {
  const res = await api.get('/agent/activity', { params: { limit } });
  return res.data;
}
