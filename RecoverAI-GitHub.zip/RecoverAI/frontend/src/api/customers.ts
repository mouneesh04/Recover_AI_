import api from './client';
import { Customer, CustomerDetail } from '../types/customer';

export async function fetchCustomers(page: number = 1, page_size: number = 20): Promise<Customer[]> {
  const res = await api.get('/customers', { params: { page, page_size } });
  return res.data;
}

export async function fetchCustomerDetail(id: string): Promise<CustomerDetail> {
  const res = await api.get(`/customers/${id}`);
  return res.data;
}
