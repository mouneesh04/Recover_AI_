import api from './client';

export async function fetchHumanReviewQueue(): Promise<any[]> {
  const res = await api.get('/recovery/human-review');
  return res.data;
}

export async function approveRecovery(transactionId: string, customStrategy?: string, notes?: string): Promise<any> {
  const res = await api.post(`/recovery/${transactionId}/approve`, {
    custom_strategy: customStrategy,
    notes: notes,
  });
  return res.data;
}

export async function rejectRecovery(transactionId: string, reason: string): Promise<any> {
  const res = await api.post(`/recovery/${transactionId}/reject`, { reason });
  return res.data;
}
