import api from './client';
import { TransactionListResponse, TransactionTimelineResponse, AnalyzeResponse } from '../types/transaction';

export async function fetchTransactions(params: {
  status?: string;
  failure_reason?: string;
  payment_method?: string;
  search?: string;
  page?: number;
  page_size?: number;
}): Promise<TransactionListResponse> {
  const res = await api.get('/transactions', { params });
  return res.data;
}

export async function fetchTransactionDetail(id: string): Promise<any> {
  const res = await api.get(`/transactions/${id}`);
  return res.data;
}

export async function fetchTransactionTimeline(id: string): Promise<TransactionTimelineResponse> {
  const res = await api.get(`/transactions/${id}/timeline`);
  return res.data;
}

export async function analyzeTransaction(id: string): Promise<AnalyzeResponse> {
  const res = await api.post(`/transactions/${id}/analyze`);
  return res.data;
}

export async function recoverTransaction(id: string): Promise<any> {
  const res = await api.post(`/transactions/${id}/recover`);
  return res.data;
}

export async function retryTransaction(id: string): Promise<any> {
  const res = await api.post(`/transactions/${id}/retry`);
  return res.data;
}

export async function remindTransaction(id: string): Promise<any> {
  const res = await api.post(`/transactions/${id}/remind`);
  return res.data;
}

export async function escalateTransaction(id: string, reason?: string): Promise<any> {
  const res = await api.post(`/transactions/${id}/escalate`, null, { params: { reason } });
  return res.data;
}
