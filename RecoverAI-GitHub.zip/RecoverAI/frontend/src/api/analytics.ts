import api from './client';
import { AnalyticsResponse } from '../types/analytics';

export async function fetchAnalytics(): Promise<AnalyticsResponse> {
  const res = await api.get('/analytics');
  return res.data;
}
