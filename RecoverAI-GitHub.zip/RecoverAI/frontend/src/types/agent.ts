export interface AgentDecision {
  id: string;
  transaction_id: string;
  step_number: number;
  strategy_chosen: string;
  confidence: number;
  reasoning_text: string;
  factors: Array<{ factor: string; impact: string; weight: string }>;
  requires_human_approval: boolean;
  approval_status: 'AUTO_APPROVED' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  created_at: string;
}

export interface AgentActivityEvent {
  id: string;
  timestamp: string;
  transaction_id: string;
  customer_name?: string;
  event_type: 'ANALYSIS' | 'PREDICTION' | 'STRATEGY_SELECTED' | 'RETRY_EXECUTED' | 'PAYMENT_RECOVERED' | 'ESCALATED' | 'REMINDER_SENT';
  headline: string;
  detail: string;
  impact_amount?: number;
  recovery_probability?: number;
  strategy?: string;
  badge_type: 'SUCCESS' | 'WARNING' | 'DANGER' | 'INFO';
}

export interface AgentRecoveryState {
  transaction_id: string;
  step_number: number;
  current_status: string;
  amount: number;
  currency: string;
  customer_id: string;
  customer_history?: Record<string, any>;
  failure_classification?: Record<string, any>;
  recovery_probability?: number;
  risk_level?: string;
  strategy_chosen?: string;
  reasoning_text?: string;
  factors: Array<Record<string, any>>;
  requires_human_approval: boolean;
  tool_history: Array<{
    tool_name: string;
    arguments: Record<string, any>;
    output: Record<string, any>;
    timestamp: string;
  }>;
  is_terminal: boolean;
  final_outcome?: string;
  recovered_amount: number;
}
