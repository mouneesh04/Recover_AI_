export interface MetricSummary {
  total_transactions: number;
  successful_transactions: number;
  failed_transactions: number;
  recoverable_failed_transactions: number;
  recovered_count: number;
  recovery_rate_pct: number;
  revenue_at_risk: number;
  revenue_recovered: number;
  pending_recovery_actions: number;
  human_review_cases: number;
  currency: string;
}

export interface ChartDataPoint {
  date: string;
  failed_count: number;
  recovered_count: number;
  revenue_at_risk: number;
  revenue_recovered: number;
  recovery_rate: number;
}

export interface CategoryBreakdown {
  name: string;
  count: number;
  percentage: number;
  recovered_count?: number;
  revenue_recovered?: number;
}

export interface DashboardMetricsResponse {
  metrics: MetricSummary;
  timeseries: ChartDataPoint[];
  failure_reasons: CategoryBreakdown[];
  payment_methods: CategoryBreakdown[];
  recovery_strategies: CategoryBreakdown[];
}
