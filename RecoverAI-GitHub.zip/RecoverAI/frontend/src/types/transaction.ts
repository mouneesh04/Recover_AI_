export interface Transaction {
  id: string;
  customer_id: string;
  customer_name?: string;
  customer_email?: string;
  amount: number;
  currency: string;
  payment_method: string;
  status: 'SUCCESS' | 'FAILED' | 'RECOVERING' | 'RECOVERED' | 'NON_RECOVERABLE' | 'MANUAL_REVIEW';
  failure_reason?: string;
  failure_code?: string;
  retry_count: number;
  max_retries: number;
  recovery_probability?: number;
  risk_level?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  recommended_strategy?: string;
  device_type?: string;
  ip_location?: string;
  network_latency_ms?: number;
  bank_response_time_ms?: number;
  failed_at?: string;
  recovered_at?: string;
  created_at: string;
}

export interface TransactionListResponse {
  items: Transaction[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface TimelineEvent {
  step: number;
  timestamp: string;
  title: string;
  description: string;
  type: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED' | 'INFO';
  metadata?: Record<string, any>;
}

export interface TransactionTimelineResponse {
  transaction_id: string;
  current_status: string;
  events: TimelineEvent[];
}

export interface AnalyzeResponse {
  transaction_id: string;
  recovery_probability: number;
  recoverable: boolean;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  recommended_strategy: string;
  explanation_summary: string;
  key_factors: Array<{ factor: string; impact: string; weight: string }>;
  positive_drivers: string[];
  negative_drivers: string[];
}
