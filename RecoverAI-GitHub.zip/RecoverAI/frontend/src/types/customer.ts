export interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string;
  tier: 'STANDARD' | 'PREMIUM' | 'VIP';
  total_transactions: number;
  successful_transactions: number;
  failed_transactions: number;
  historical_success_rate: number;
  avg_transaction_amount: number;
  last_payment_at?: string;
  created_at: string;
}

export interface CustomerDetail extends Customer {
  recent_transactions: Array<any>;
}
