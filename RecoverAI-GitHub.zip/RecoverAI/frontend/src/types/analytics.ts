export interface StrategyROI {
  strategy: string;
  attempted_count: number;
  success_count: number;
  success_rate: number;
  revenue_recovered: number;
  avg_recovery_time_mins: number;
}

export interface AmountTierData {
  tier: string;
  total_count: number;
  recovered_count: number;
  recovery_rate: number;
}

export interface CustomerTypeData {
  customer_tier: string;
  total_count: number;
  recovered_count: number;
  recovery_rate: number;
}

export interface AnalyticsResponse {
  strategy_roi: StrategyROI[];
  recovery_by_amount_tier: AmountTierData[];
  recovery_by_customer_type: CustomerTypeData[];
  failure_recovery_matrix: Array<Record<string, any>>;
  ml_model_metrics: Record<string, any>;
}
