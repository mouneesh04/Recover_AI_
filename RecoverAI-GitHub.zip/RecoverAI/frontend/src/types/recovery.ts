export interface HumanReviewItem {
  id: string;
  customer_id: string;
  customer_name: string;
  customer_tier: string;
  amount: number;
  currency: string;
  payment_method: string;
  failure_reason: string;
  retry_count: number;
  recovery_probability: number;
  recommended_strategy: string;
  escalation_reason: string;
  risk_level: string;
  created_at: string;
  factors: Array<{ factor: string; impact: string; weight: string }>;
}
