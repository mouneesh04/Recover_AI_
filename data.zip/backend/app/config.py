import os
from pydantic_settings import BaseSettings
from typing import List, Union
from pydantic import field_validator

class Settings(BaseSettings):
    PROJECT_NAME: str = "RecoverAI"
    VERSION: str = "1.0.0"
    DESCRIPTION: str = "Autonomous Failed Payment Recovery Agent"
    ENVIRONMENT: str = "development"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # CORS
    CORS_ORIGINS: Union[str, List[str]] = "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000"
    
    # Database
    DATABASE_URL: str = "sqlite:///./recoverai.db"
    
    # Agent Safety Policies
    MAX_RETRY_ATTEMPTS: int = 3
    AUTO_RECOVERY_MAX_AMOUNT: float = 25000.0 # INR 25,000
    MIN_RECOVERY_CONFIDENCE: float = 0.35
    SIMULATION_LATENCY_MS: int = 150
    
    # LLM Settings
    LLM_PROVIDER: str = "heuristic" # 'heuristic', 'gemini', 'openai', 'anthropic'
    GEMINI_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    
    @property
    def cors_origins_list(self) -> List[str]:
        if isinstance(self.CORS_ORIGINS, list):
            return self.CORS_ORIGINS
        if isinstance(self.CORS_ORIGINS, str):
            return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]
        return ["*"]

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
