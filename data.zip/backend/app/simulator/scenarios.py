from typing import Dict, Any, List

DEMO_SCENARIO: Dict[str, Any] = {
    "id": "TXN-DEMO-001",
    "customer_id": "CUST-1001",
    "amount": 8999.00,
    "currency": "INR",
    "payment_method": "UPI",
    "failure_reason": "BANK_TIMEOUT",
    "failure_code": "PSP_TIMEOUT_504",
    "retry_count": 0,
    "max_retries": 3,
    "recovery_probability": 0.91,
    "risk_level": "LOW",
    "recommended_strategy": "RETRY_LATER",
    "device_type": "MOBILE",
    "ip_location": "Bengaluru, IN",
    "network_latency_ms": 110,
    "bank_response_time_ms": 4200,
    "status": "FAILED"
}

TEST_SCENARIOS: List[Dict[str, Any]] = [
    {
        "name": "Temporary Bank Latency (High Recovery)",
        "transaction_id": "TXN-SCENARIO-01",
        "amount": 4500.0,
        "payment_method": "UPI",
        "failure_reason": "BANK_TIMEOUT",
        "expected_strategy": "RETRY_LATER"
    },
    {
        "name": "High Value Transaction (Human Approval Required)",
        "transaction_id": "TXN-SCENARIO-02",
        "amount": 65000.0, # > ₹25,000 threshold
        "payment_method": "CARD",
        "failure_reason": "BANK_TIMEOUT",
        "expected_strategy": "ESCALATE_TO_HUMAN"
    },
    {
        "name": "Expired Card (Alternative Payment Method)",
        "transaction_id": "TXN-SCENARIO-03",
        "amount": 2499.0,
        "payment_method": "CARD",
        "failure_reason": "CARD_EXPIRED",
        "expected_strategy": "SUGGEST_ALTERNATIVE_PAYMENT_METHOD"
    },
    {
        "name": "Insufficient Funds (Payment Reminder)",
        "transaction_id": "TXN-SCENARIO-04",
        "amount": 1299.0,
        "payment_method": "NETBANKING",
        "failure_reason": "INSUFFICIENT_FUNDS",
        "expected_strategy": "SEND_PAYMENT_REMINDER"
    }
]
