import random
import time
import uuid
from typing import Dict, Any, Optional

class PaymentGatewaySimulator:
    """
    Simulated Payment Gateway for RecoverAI.
    Models realistic banking network latency and context-dependent recovery outcomes.
    Zero real financial operations.
    """
    
    def __init__(self, base_latency_ms: int = 150):
        self.base_latency_ms = base_latency_ms

    def process_retry(
        self,
        transaction_id: str,
        amount: float,
        payment_method: str,
        failure_reason: str,
        retry_count: int,
        test_seed: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Simulates retrying a payment through the issuing bank / card network / UPI switch.
        """
        # Reproducibility support for demo / tests
        if test_seed is not None:
            rng = random.Random(test_seed)
        else:
            rng = random.Random()
            
        # Demo scenario override: TXN-DEMO-001 always succeeds on first retry
        if transaction_id == "TXN-DEMO-001":
            sim_latency = self.base_latency_ms + 45
            return {
                "status": "SUCCESS",
                "transaction_id": transaction_id,
                "amount": amount,
                "currency": "INR",
                "payment_method": payment_method,
                "gateway_reference_id": f"GW-DEMO-{uuid.uuid4().hex[:8].upper()}",
                "bank_arn": f"ARN{random.randint(100000000, 999999999)}",
                "auth_code": "AUTH99812",
                "message": "Payment captured successfully on scheduled retry.",
                "latency_ms": sim_latency
            }
            
        # Probability calculation based on failure type and retry attempt
        prob_success = 0.50
        reason_upper = (failure_reason or "").upper()
        
        if reason_upper in ["BANK_TIMEOUT", "NETWORK_ERROR", "GATEWAY_ERROR"]:
            prob_success = 0.88 - (retry_count * 0.15)
        elif reason_upper in ["UPI_FAILURE"]:
            prob_success = 0.82 - (retry_count * 0.12)
        elif reason_upper in ["INSUFFICIENT_FUNDS"]:
            prob_success = 0.40 - (retry_count * 0.10)
        elif reason_upper in ["BANK_DECLINED"]:
            prob_success = 0.25 - (retry_count * 0.08)
        elif reason_upper in ["CARD_EXPIRED", "INVALID_DETAILS"]:
            prob_success = 0.02 # Permanent failures almost always fail without instrument change
        else:
            prob_success = 0.45
            
        prob_success = max(0.01, min(0.98, prob_success))
        
        # Determine simulated outcome
        is_success = rng.random() < prob_success
        sim_latency = self.base_latency_ms + rng.randint(20, 180)
        
        if is_success:
            return {
                "status": "SUCCESS",
                "transaction_id": transaction_id,
                "amount": amount,
                "currency": "INR",
                "payment_method": payment_method,
                "gateway_reference_id": f"GW-RECOV-{uuid.uuid4().hex[:8].upper()}",
                "bank_arn": f"ARN{rng.randint(100000000, 999999999)}",
                "auth_code": f"AUTH{rng.randint(10000, 99999)}",
                "message": "Payment successfully authorized and captured.",
                "latency_ms": sim_latency
            }
        else:
            # Generate appropriate failure response
            if reason_upper in ["BANK_TIMEOUT", "UPI_FAILURE"]:
                err_code = "BANK_STILL_UNAVAILABLE"
                err_msg = "Issuing bank switch unresponsive during retry."
            elif reason_upper == "INSUFFICIENT_FUNDS":
                err_code = "INSUFFICIENT_FUNDS"
                err_msg = "Account balance still below transaction requirement."
            elif reason_upper in ["CARD_EXPIRED", "INVALID_DETAILS"]:
                err_code = "INSTRUMENT_INVALID"
                err_msg = "Card details expired or invalid."
            else:
                err_code = "GATEWAY_DECLINE"
                err_msg = "Upstream payment provider declined the retry attempt."
                
            return {
                "status": "FAILED",
                "transaction_id": transaction_id,
                "amount": amount,
                "currency": "INR",
                "payment_method": payment_method,
                "gateway_reference_id": f"GW-ERR-{uuid.uuid4().hex[:8].upper()}",
                "error_code": err_code,
                "message": err_msg,
                "latency_ms": sim_latency
            }

    def generate_alternative_payment_link(self, transaction_id: str, amount: float, customer_email: str) -> Dict[str, Any]:
        """Simulates creating an alternative smart checkout recovery link."""
        link_id = f"paylink_{uuid.uuid4().hex[:10]}"
        return {
            "status": "GENERATED",
            "payment_link_id": link_id,
            "checkout_url": f"https://checkout.recoverai.demo/pay/{link_id}",
            "expires_in_hours": 24,
            "allowed_methods": ["UPI", "NETBANKING", "WALLET", "NEW_CARD"],
            "amount": amount,
            "customer_email": customer_email
        }

gateway_simulator = PaymentGatewaySimulator()
