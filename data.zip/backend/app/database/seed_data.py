import os
import sys
import random
import uuid
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Ensure root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

from backend.app.database.connection import engine, SessionLocal, Base
from backend.app.models.customer import Customer
from backend.app.models.transaction import Transaction
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.notification import Notification
from backend.app.models.audit_log import AuditLog
from backend.app.simulator.scenarios import DEMO_SCENARIO

def seed_database():
    print("[RecoverAI DB] Initializing tables and seeding initial data...")
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        # Clear existing rows
        db.query(RecoveryResult).delete()
        db.query(RecoveryAction).delete()
        db.query(AgentDecision).delete()
        db.query(Notification).delete()
        db.query(AuditLog).delete()
        db.query(Transaction).delete()
        db.query(Customer).delete()
        db.commit()
        
        # 1. Seed 50 realistic customers
        customers = []
        customer_names = [
            ("Rahul Sharma", "rahul.sharma@example.com", "+91 98765 43210", "PREMIUM"),
            ("Priya Patel", "priya.patel@techcorp.in", "+91 98234 56789", "VIP"),
            ("Amit Verma", "amit.verma@outlook.com", "+91 97112 34567", "STANDARD"),
            ("Sneha Reddy", "sneha.reddy@gmail.com", "+91 99887 65432", "PREMIUM"),
            ("Vikram Malhotra", "vikram.m@fintech.io", "+91 96543 21098", "VIP"),
            ("Ananya Desai", "ananya.d@enterprise.com", "+91 95432 10987", "STANDARD"),
            ("Rohan Gupta", "rohan.gupta@startup.ai", "+91 94321 09876", "VIP"),
            ("Kavita Nair", "kavita.nair@service.net", "+91 93210 98765", "STANDARD"),
            ("Deepak Joshi", "deepak.j@commerce.in", "+91 92109 87654", "PREMIUM"),
            ("Pooja Iyer", "pooja.iyer@digital.co", "+91 91098 76543", "STANDARD")
        ]
        
        for idx in range(1, 41):
            if idx <= len(customer_names):
                name, email, phone, tier = customer_names[idx - 1]
            else:
                name = f"Customer {1000 + idx}"
                email = f"user{1000 + idx}@example.com"
                phone = f"+91 {random.randint(90000, 99999)} {random.randint(10000, 99999)}"
                tier = random.choice(["STANDARD", "PREMIUM", "VIP"])
                
            total_txns = random.randint(3, 25)
            succ_rate = round(random.uniform(0.70, 0.96), 2)
            succ_txns = int(total_txns * succ_rate)
            fail_txns = total_txns - succ_txns
            avg_amt = round(random.uniform(2500, 18000), 2)
            
            cust = Customer(
                id=f"CUST-{1000 + idx}",
                name=name,
                email=email,
                phone=phone,
                tier=tier,
                total_transactions=total_txns,
                successful_transactions=succ_txns,
                failed_transactions=fail_txns,
                historical_success_rate=succ_rate,
                avg_transaction_amount=avg_amt,
                last_payment_at=datetime.utcnow() - timedelta(days=random.randint(1, 20))
            )
            customers.append(cust)
            db.add(cust)
            
        db.commit()
        print(f"[RecoverAI DB] Seeded {len(customers)} customers.")
        
        # 2. Seed 250 realistic transactions spanning past 7 days
        methods = ["UPI", "CARD", "NETBANKING", "WALLET"]
        failure_reasons = [
            "BANK_TIMEOUT", "NETWORK_ERROR", "INSUFFICIENT_FUNDS",
            "UPI_FAILURE", "BANK_DECLINED", "CARD_EXPIRED", "GATEWAY_ERROR"
        ]
        
        now = datetime.utcnow()
        transactions = []
        
        for i in range(1, 251):
            txn_id = f"TXN-{200000 + i}"
            cust = random.choice(customers)
            method = random.choice(methods)
            amount = round(float(np.random.lognormal(mean=7.6, sigma=0.7)), 2)
            
            # Timestamp distributed over last 7 days
            days_ago = random.randint(0, 6)
            hours_ago = random.randint(0, 23)
            txn_time = now - timedelta(days=days_ago, hours=hours_ago, minutes=random.randint(0, 59))
            
            # 65% initial success, 35% failure
            is_initial_success = random.random() < 0.65
            
            if is_initial_success:
                txn = Transaction(
                    id=txn_id,
                    customer_id=cust.id,
                    amount=amount,
                    currency="INR",
                    payment_method=method,
                    status="SUCCESS",
                    device_type=random.choice(["MOBILE", "DESKTOP"]),
                    ip_location=random.choice(["Mumbai, IN", "Bengaluru, IN", "Delhi NCR, IN", "Hyderabad, IN"]),
                    network_latency_ms=random.randint(60, 180),
                    bank_response_time_ms=random.randint(400, 950),
                    created_at=txn_time
                )
            else:
                reason = random.choice(failure_reasons)
                # Compute probability
                prob = 0.88 if reason in ["BANK_TIMEOUT", "NETWORK_ERROR", "GATEWAY_ERROR"] else (
                    0.78 if reason == "UPI_FAILURE" else (
                        0.45 if reason == "INSUFFICIENT_FUNDS" else 0.20
                    )
                )
                
                # Assign status lifecycle
                rand_outcome = random.random()
                if amount > 25000:
                    status = "MANUAL_REVIEW"
                    strategy = "ESCALATE_TO_HUMAN"
                elif rand_outcome < 0.60: # 60% of recoverable failures got recovered
                    status = "RECOVERED"
                    strategy = "RETRY_LATER" if reason == "BANK_TIMEOUT" else "RETRY_NOW"
                elif rand_outcome < 0.80:
                    status = "RECOVERING"
                    strategy = "RETRY_LATER" if reason in ["BANK_TIMEOUT", "UPI_FAILURE"] else "SEND_PAYMENT_REMINDER"
                else:
                    status = "FAILED"
                    strategy = "SUGGEST_ALTERNATIVE_PAYMENT_METHOD" if reason in ["CARD_EXPIRED", "BANK_DECLINED"] else "RETRY_LATER"
                    
                txn = Transaction(
                    id=txn_id,
                    customer_id=cust.id,
                    amount=amount,
                    currency="INR",
                    payment_method=method,
                    status=status,
                    failure_reason=reason,
                    failure_code=f"ERR_{reason[:4]}_{random.randint(100, 999)}",
                    retry_count=1 if status in ["RECOVERED", "RECOVERING"] else 0,
                    max_retries=3,
                    recovery_probability=prob,
                    risk_level="LOW" if prob > 0.7 else ("MEDIUM" if prob > 0.4 else "HIGH"),
                    recommended_strategy=strategy,
                    device_type=random.choice(["MOBILE", "DESKTOP"]),
                    ip_location=random.choice(["Mumbai, IN", "Bengaluru, IN", "Delhi NCR, IN", "Hyderabad, IN"]),
                    network_latency_ms=random.randint(110, 450),
                    bank_response_time_ms=random.randint(900, 4800),
                    failed_at=txn_time,
                    recovered_at=txn_time + timedelta(minutes=18) if status == "RECOVERED" else None,
                    created_at=txn_time
                )
                
            transactions.append(txn)
            db.add(txn)
            
        db.commit()
        print(f"[RecoverAI DB] Seeded {len(transactions)} transactions.")
        
        # 3. Create Demo Transaction TXN-DEMO-001
        demo_cust = db.query(Customer).filter(Customer.id == "CUST-1001").first()
        demo_txn = Transaction(
            id=DEMO_SCENARIO["id"],
            customer_id=demo_cust.id,
            amount=DEMO_SCENARIO["amount"],
            currency=DEMO_SCENARIO["currency"],
            payment_method=DEMO_SCENARIO["payment_method"],
            status="FAILED",
            failure_reason=DEMO_SCENARIO["failure_reason"],
            failure_code=DEMO_SCENARIO["failure_code"],
            retry_count=0,
            max_retries=3,
            recovery_probability=0.91,
            risk_level="LOW",
            recommended_strategy="RETRY_LATER",
            device_type="MOBILE",
            ip_location="Bengaluru, IN",
            network_latency_ms=110,
            bank_response_time_ms=4200,
            failed_at=now - timedelta(minutes=8),
            created_at=now - timedelta(minutes=8)
        )
        db.add(demo_txn)
        
        # Add initial audit log for demo
        db.add(AuditLog(
            id="AUD-INIT-DEMO",
            actor="SYSTEM",
            action="PAYMENT_FAILED",
            entity_type="TRANSACTION",
            entity_id=DEMO_SCENARIO["id"],
            reason="Transaction failed at payment gateway due to BANK_TIMEOUT."
        ))
        db.commit()
        print(f"[RecoverAI DB] Seeded master demo transaction: {DEMO_SCENARIO['id']}")
        
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
