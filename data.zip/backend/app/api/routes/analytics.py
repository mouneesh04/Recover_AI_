from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.api.deps import get_db
from backend.app.services.analytics_service import AnalyticsService
from backend.app.schemas.analytics import AnalyticsResponse

router = APIRouter(prefix="/analytics", tags=["Analytics & Model Performance"])

@router.get("", response_model=AnalyticsResponse)
def get_analytics(db: Session = Depends(get_db)):
    """Retrieves deep-dive ML model performance metrics, strategy ROI, and tier analytics."""
    return AnalyticsService.get_deep_analytics(db)
