from fastapi import APIRouter
from backend.app.api.routes.dashboard import router as dashboard_router
from backend.app.api.routes.transactions import router as transactions_router
from backend.app.api.routes.agent import router as agent_router
from backend.app.api.routes.recovery import router as recovery_router
from backend.app.api.routes.customers import router as customers_router
from backend.app.api.routes.analytics import router as analytics_router
from backend.app.api.routes.simulator import router as simulator_router

api_router = APIRouter(prefix="/api")
api_router.include_router(dashboard_router)
api_router.include_router(transactions_router)
api_router.include_router(agent_router)
api_router.include_router(recovery_router)
api_router.include_router(customers_router)
api_router.include_router(analytics_router)
api_router.include_router(simulator_router)

__all__ = ["api_router"]
