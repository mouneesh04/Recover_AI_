from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import Dict, Any

from backend.app.api.deps import get_db
from backend.app.simulator.scenarios import DEMO_SCENARIO
from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.models.audit_log import AuditLog
from backend.app.database.seed_data import seed_database
from backend.app.simulator.payment_gateway import gateway_simulator

router = APIRouter(prefix="/simulator", tags=["Payment Simulator & Scenarios"])

@router.post("/seed-demo")
def seed_demo_scenario(db: Session = Depends(get_db)) -> Dict[str, Any]:
    """
    Initializes or resets the official 5-minute presentation demo transaction: TXN-DEMO-001.
    Amount: ₹8,999 | Customer: Returning | Failure: BANK_TIMEOUT | Status: FAILED
    """
    txn_id = DEMO_SCENARIO["id"]
    cust_id = DEMO_SCENARIO["customer_id"]
    
    # Ensure customer exists
    cust = db.query(Customer).filter(Customer.id == cust_id).first()
    if not cust:
        cust = Customer(
            id=cust_id,
            name="Rahul Sharma",
            email="rahul.sharma@example.com",
            phone="+91 98765 43210",
            tier="PREMIUM",
            total_transactions=14,
            successful_transactions=12,
            failed_transactions=2,
            historical_success_rate=0.857,
            avg_transaction_amount=7800.00
        )
        db.add(cust)
        db.commit()

    # Clear prior demo logs
    db.query(RecoveryResult).filter(RecoveryResult.transaction_id == txn_id).delete()
    db.query(RecoveryAction).filter(RecoveryAction.transaction_id == txn_id).delete()
    db.query(AgentDecision).filter(AgentDecision.transaction_id == txn_id).delete()
    db.query(AuditLog).filter(AuditLog.entity_id == txn_id).delete()
    db.query(Transaction).filter(Transaction.id == txn_id).delete()
    db.commit()

    # Create fresh demo transaction
    demo_txn = Transaction(
        id=txn_id,
        customer_id=cust_id,
        amount=DEMO_SCENARIO["amount"],
        currency=DEMO_SCENARIO["currency"],
        payment_method=DEMO_SCENARIO["payment_method"],
        status="FAILED",
        failure_reason=DEMO_SCENARIO["failure_reason"],
        failure_code=DEMO_SCENARIO["failure_code"],
        retry_count=0,
        max_retries=3,
        recovery_probability=0.91,
        risk_level="LOW",
        recommended_strategy="RETRY_LATER",
        device_type="MOBILE",
        ip_location="Bengaluru, IN",
        network_latency_ms=110,
        bank_response_time_ms=4200
    )
    db.add(demo_txn)

    # Initial failure audit log
    audit = AuditLog(
        id=f"AUD-DEMO-INIT",
        actor="SYSTEM",
        action="PAYMENT_FAILED",
        entity_type="TRANSACTION",
        entity_id=txn_id,
        reason="Initial payment attempt failed due to BANK_TIMEOUT (PSP_TIMEOUT_504)."
    )
    db.add(audit)
    db.commit()

    return {
        "status": "SEEDED",
        "message": "Demo transaction TXN-DEMO-001 successfully initialized.",
        "transaction": DEMO_SCENARIO
    }

@router.post("/reset")
def reset_database_data(db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Resets entire database and re-seeds synthetic records and demo scenarios."""
    seed_database()
    return {"status": "SUCCESS", "message": "Database reset and seeded successfully."}

@router.post("/config")
def update_simulator_config(latency_ms: int = 150) -> Dict[str, Any]:
    """Updates simulated payment gateway response latency."""
    gateway_simulator.base_latency_ms = latency_ms
    return {"status": "UPDATED", "base_latency_ms": latency_ms}
