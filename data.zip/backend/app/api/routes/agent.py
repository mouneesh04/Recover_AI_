from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List
from datetime import datetime

from backend.app.api.deps import get_db
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.models.audit_log import AuditLog
from backend.app.schemas.agent import AgentActivityEvent

router = APIRouter(prefix="/agent", tags=["Agent Activity"])

@router.get("/activity", response_model=List[AgentActivityEvent])
def get_live_agent_activity(
    limit: int = Query(25, ge=5, le=100),
    db: Session = Depends(get_db)
):
    """
    Returns real-time streaming feed of autonomous agent actions, ML predictions,
    and recovered revenues across the system.
    """
    # Fetch recent audit logs joined with transaction & customer
    audits = db.query(AuditLog, Transaction, Customer)\
        .outerjoin(Transaction, AuditLog.entity_id == Transaction.id)\
        .outerjoin(Customer, Transaction.customer_id == Customer.id)\
        .order_by(desc(AuditLog.timestamp))\
        .limit(limit)\
        .all()
        
    events: List[AgentActivityEvent] = []
    for audit, txn, cust in audits:
        txn_id = txn.id if txn else (audit.entity_id or "SYSTEM")
        cust_name = cust.name if cust else "Customer"
        action = audit.action
        
        # Format user-friendly headline and badges
        if action == "PAYMENT_RECOVERED":
            headline = f"Payment Recovered: ₹{txn.amount:,.2f}" if txn else "Payment Recovered"
            badge = "SUCCESS"
            evt_type = "PAYMENT_RECOVERED"
        elif action == "EXECUTE_RETRY" or action == "APPROVE_RECOVERY":
            headline = f"Retry Executed for {txn_id}"
            badge = "INFO"
            evt_type = "RETRY_EXECUTED"
        elif action == "ROUTE_TO_HUMAN_REVIEW" or action == "ESCALATE_TO_HUMAN":
            headline = f"Escalated to Human Queue: {txn_id}"
            badge = "WARNING"
            evt_type = "ESCALATED"
        elif action == "SEND_REMINDER":
            headline = f"Recovery Reminder Sent to {cust_name}"
            badge = "INFO"
            evt_type = "REMINDER_SENT"
        elif action == "GENERATE_ALT_LINK":
            headline = f"Smart Payment Link Created for {cust_name}"
            badge = "INFO"
            evt_type = "STRATEGY_SELECTED"
        else:
            headline = f"Agent Action: {action.replace('_', ' ').title()}"
            badge = "INFO"
            evt_type = "ANALYSIS"
            
        events.append(AgentActivityEvent(
            id=audit.id,
            timestamp=audit.timestamp,
            transaction_id=txn_id,
            customer_name=cust_name,
            event_type=evt_type,
            headline=headline,
            detail=audit.reason or "Agent executed autonomous policy workflow.",
            impact_amount=txn.amount if (txn and action == "PAYMENT_RECOVERED") else None,
            recovery_probability=txn.recovery_probability if txn else None,
            strategy=txn.recommended_strategy if txn else None,
            badge_type=badge
        ))
        
    return events
