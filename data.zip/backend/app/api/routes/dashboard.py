from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.api.deps import get_db
from backend.app.services.analytics_service import AnalyticsService
from backend.app.schemas.dashboard import DashboardMetricsResponse

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/metrics", response_model=DashboardMetricsResponse)
def get_dashboard_metrics(db: Session = Depends(get_db)):
    """Fetches high-level executive recovery KPIs, timeseries charts, and categorical breakdowns."""
    return AnalyticsService.get_dashboard_metrics(db)
