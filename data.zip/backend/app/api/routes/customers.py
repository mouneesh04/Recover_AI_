from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List

from backend.app.api.deps import get_db
from backend.app.services.customer_service import CustomerService
from backend.app.schemas.customer import CustomerRead, CustomerDetail

router = APIRouter(prefix="/customers", tags=["Customers"])

@router.get("", response_model=List[CustomerRead])
def list_customers(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves list of customers with payment fidelity, historical success rates, and tiers."""
    return CustomerService.get_customers(db, page, page_size)

@router.get("/{customer_id}", response_model=CustomerDetail)
def get_customer(customer_id: str, db: Session = Depends(get_db)):
    """Retrieves customer profile with recent transaction and recovery history."""
    detail = CustomerService.get_customer_detail(db, customer_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Customer not found")
    return detail
