from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any

from backend.app.api.deps import get_db
from backend.app.services.transaction_service import TransactionService
from backend.app.schemas.transaction import (
    TransactionListResponse, TransactionTimelineResponse, AnalyzeResponse
)
from backend.app.ml.inference import predictor
from backend.app.agents.recovery_agent import AutonomousRecoveryAgent
from backend.app.agents.tools import AgentToolRegistry
from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer

router = APIRouter(prefix="/transactions", tags=["Transactions"])

@router.get("", response_model=TransactionListResponse)
def list_transactions(
    status: Optional[str] = Query(None, description="Filter by status (e.g. FAILED, RECOVERED, MANUAL_REVIEW)"),
    failure_reason: Optional[str] = Query(None, description="Filter by failure reason"),
    payment_method: Optional[str] = Query(None, description="Filter by payment method"),
    search: Optional[str] = Query(None, description="Search by ID, customer name or email"),
    page: int = Query(1, ge=1),
    page_size: int = Query(15, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves paginated, searchable, and filterable payment transactions."""
    return TransactionService.get_transactions(
        db=db,
        status=status,
        failure_reason=failure_reason,
        payment_method=payment_method,
        search=search,
        page=page,
        page_size=page_size
    )

@router.get("/{transaction_id}")
def get_transaction_details(transaction_id: str, db: Session = Depends(get_db)):
    """Retrieves complete details for a single transaction including customer profile and decisions."""
    data = TransactionService.get_transaction_by_id(db, transaction_id)
    if not data:
        raise HTTPException(status_code=404, detail="Transaction not found")
        
    txn = data["transaction"]
    cust = data["customer"]
    decision = data["latest_decision"]
    actions = data["actions"]
    
    return {
        "transaction": {
            "id": txn.id,
            "amount": txn.amount,
            "currency": txn.currency,
            "payment_method": txn.payment_method,
            "status": txn.status,
            "failure_reason": txn.failure_reason,
            "failure_code": txn.failure_code,
            "retry_count": txn.retry_count,
            "max_retries": txn.max_retries,
            "recovery_probability": txn.recovery_probability,
            "risk_level": txn.risk_level,
            "recommended_strategy": txn.recommended_strategy,
            "device_type": txn.device_type,
            "ip_location": txn.ip_location,
            "network_latency_ms": txn.network_latency_ms,
            "bank_response_time_ms": txn.bank_response_time_ms,
            "failed_at": txn.failed_at,
            "recovered_at": txn.recovered_at,
            "created_at": txn.created_at
        },
        "customer": {
            "id": cust.id,
            "name": cust.name,
            "email": cust.email,
            "phone": cust.phone,
            "tier": cust.tier,
            "total_transactions": cust.total_transactions,
            "successful_transactions": cust.successful_transactions,
            "failed_transactions": cust.failed_transactions,
            "historical_success_rate": cust.historical_success_rate,
            "avg_transaction_amount": cust.avg_transaction_amount,
            "last_payment_at": cust.last_payment_at
        },
        "latest_decision": {
            "id": decision.id,
            "strategy_chosen": decision.strategy_chosen,
            "confidence": decision.confidence,
            "reasoning_text": decision.reasoning_text,
            "requires_human_approval": decision.requires_human_approval,
            "approval_status": decision.approval_status,
            "created_at": decision.created_at
        } if decision else None,
        "actions_count": len(actions)
    }

@router.get("/{transaction_id}/timeline", response_model=TransactionTimelineResponse)
def get_transaction_timeline(transaction_id: str, db: Session = Depends(get_db)):
    """Retrieves step-by-step chronological action timeline for a transaction."""
    return TransactionService.build_timeline(db, transaction_id)

@router.post("/{transaction_id}/analyze", response_model=AnalyzeResponse)
def analyze_transaction(transaction_id: str, db: Session = Depends(get_db)):
    """Triggers ML model inference and SHAP explainability scoring for a transaction."""
    txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
        
    cust = db.query(Customer).filter(Customer.id == txn.customer_id).first()
    cust_dict = {
        "total_transactions": cust.total_transactions if cust else 1,
        "successful_transactions": cust.successful_transactions if cust else 1,
        "failed_transactions": cust.failed_transactions if cust else 0,
        "historical_success_rate": cust.historical_success_rate if cust else 0.9,
        "avg_transaction_amount": cust.avg_transaction_amount if cust else txn.amount,
        "customer_age_days": 120
    }
    
    txn_dict = {
        "amount": txn.amount,
        "payment_method": txn.payment_method,
        "device_type": txn.device_type,
        "hour": txn.created_at.hour if txn.created_at else 14,
        "day_of_week": txn.created_at.weekday() if txn.created_at else 2,
        "retry_count": txn.retry_count,
        "network_latency_ms": txn.network_latency_ms,
        "bank_response_time_ms": txn.bank_response_time_ms,
        "failure_reason": txn.failure_reason
    }
    
    prediction = predictor.predict(txn_dict, cust_dict)
    
    # Update transaction model
    txn.recovery_probability = prediction["recovery_probability"]
    txn.recommended_strategy = prediction["recommended_strategy"]
    txn.risk_level = prediction["risk_level"]
    db.commit()
    
    return AnalyzeResponse(
        transaction_id=transaction_id,
        recovery_probability=prediction["recovery_probability"],
        recoverable=prediction["recoverable"],
        risk_level=prediction["risk_level"],
        recommended_strategy=prediction["recommended_strategy"],
        explanation_summary=prediction["explanation_summary"],
        key_factors=prediction["key_factors"],
        positive_drivers=prediction["positive_drivers"],
        negative_drivers=prediction["negative_drivers"]
    )

@router.post("/{transaction_id}/recover")
def trigger_agent_recovery(transaction_id: str, db: Session = Depends(get_db)):
    """Triggers the complete Autonomous AI Recovery Agent workflow for this transaction."""
    agent = AutonomousRecoveryAgent(db=db)
    final_state = agent.run_recovery_loop(transaction_id)
    return final_state

@router.post("/{transaction_id}/retry")
def manual_retry_transaction(transaction_id: str, db: Session = Depends(get_db)):
    """Manually invokes payment retry via the simulator."""
    txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
        
    res = AgentToolRegistry.retry_payment(
        transaction_id=txn.id,
        amount=txn.amount,
        payment_method=txn.payment_method,
        failure_reason=txn.failure_reason,
        retry_count=txn.retry_count,
        db=db
    )
    return res

@router.post("/{transaction_id}/remind")
def manual_send_reminder(transaction_id: str, db: Session = Depends(get_db)):
    """Manually dispatches a customer payment reminder."""
    txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
        
    res = AgentToolRegistry.send_payment_reminder(
        transaction_id=txn.id,
        customer_id=txn.customer_id,
        channel="EMAIL",
        db=db
    )
    return res

@router.post("/{transaction_id}/escalate")
def manual_escalate_transaction(transaction_id: str, reason: str = "Merchant requested manual escalation", db: Session = Depends(get_db)):
    """Escalates transaction to the Human Review Queue."""
    res = AgentToolRegistry.escalate_to_human(transaction_id, reason, db)
    return res
