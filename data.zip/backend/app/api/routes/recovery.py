from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from backend.app.api.deps import get_db
from backend.app.services.recovery_service import RecoveryService
from backend.app.schemas.recovery import HumanReviewItem, ApproveActionRequest, RejectActionRequest

router = APIRouter(prefix="/recovery", tags=["Recovery & Human in the Loop"])

@router.get("/human-review", response_model=List[HumanReviewItem])
def list_human_review_queue(db: Session = Depends(get_db)):
    """Retrieves all pending high-value or escalated transactions in the Human Review Queue."""
    return RecoveryService.get_human_review_queue(db)

@router.post("/{transaction_id}/approve")
def approve_recovery_action(
    transaction_id: str,
    req: ApproveActionRequest = ApproveActionRequest(),
    db: Session = Depends(get_db)
):
    """Operator approves recovery action for an escalated transaction."""
    res = RecoveryService.approve_action(db, transaction_id, req.custom_strategy, req.notes)
    if "error" in res:
        raise HTTPException(status_code=404, detail=res["error"])
    return res

@router.post("/{transaction_id}/reject")
def reject_recovery_action(
    transaction_id: str,
    req: RejectActionRequest,
    db: Session = Depends(get_db)
):
    """Operator rejects recovery action for an escalated transaction."""
    res = RecoveryService.reject_action(db, transaction_id, req.reason)
    if "error" in res:
        raise HTTPException(status_code=404, detail=res["error"])
    return res
