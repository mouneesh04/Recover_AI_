from backend.app.database.connection import get_db

# Export DB session dependency
__all__ = ["get_db"]
