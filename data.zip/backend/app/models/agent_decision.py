from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class AgentDecision(Base):
    __tablename__ = "agent_decisions"

    id = Column(String(50), primary_key=True, index=True) # e.g. "DEC-1001"
    transaction_id = Column(String(50), ForeignKey("transactions.id"), nullable=False, index=True)
    
    step_number = Column(Integer, default=1)
    strategy_chosen = Column(String(50), nullable=False)
    confidence = Column(Float, nullable=False) # 0.0 to 1.0
    reasoning_text = Column(Text, nullable=False)
    factors_json = Column(Text, nullable=True) # JSON list of explainability factors
    
    requires_human_approval = Column(Boolean, default=False)
    approval_status = Column(String(30), default="AUTO_APPROVED") # AUTO_APPROVED, PENDING_APPROVAL, APPROVED, REJECTED
    tool_calls_log = Column(Text, nullable=True) # Record of tools invoked
    
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    transaction = relationship("Transaction", back_populates="agent_decisions")
