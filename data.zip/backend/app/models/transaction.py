from sqlalchemy import Column, String, Integer, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(String(50), primary_key=True, index=True) # e.g. "TXN-DEMO-001"
    customer_id = Column(String(50), ForeignKey("customers.id"), nullable=False, index=True)
    
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="INR")
    payment_method = Column(String(30), nullable=False) # CARD, UPI, NETBANKING, WALLET
    
    # Status lifecycle: SUCCESS, FAILED, RECOVERING, RECOVERED, NON_RECOVERABLE, MANUAL_REVIEW
    status = Column(String(30), default="FAILED", index=True)
    
    # Failure taxonomy
    failure_reason = Column(String(50), nullable=True, index=True) # BANK_TIMEOUT, INSUFFICIENT_FUNDS, etc.
    failure_code = Column(String(50), nullable=True)
    
    # Recovery Metrics
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    recovery_probability = Column(Float, nullable=True) # 0.0 to 1.0
    risk_level = Column(String(20), default="LOW") # LOW, MEDIUM, HIGH, CRITICAL
    recommended_strategy = Column(String(50), nullable=True) # RETRY_NOW, RETRY_LATER, etc.
    
    # Contextual metadata
    device_type = Column(String(30), default="MOBILE") # MOBILE, DESKTOP, TABLET
    ip_location = Column(String(100), default="Mumbai, IN")
    network_latency_ms = Column(Integer, default=120)
    bank_response_time_ms = Column(Integer, default=850)
    metadata_json = Column(Text, nullable=True) # Store JSON string for flexible diagnostics
    
    failed_at = Column(DateTime, default=datetime.utcnow)
    recovered_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    customer = relationship("Customer", back_populates="transactions")
    recovery_actions = relationship("RecoveryAction", back_populates="transaction", cascade="all, delete-orphan")
    recovery_results = relationship("RecoveryResult", back_populates="transaction", cascade="all, delete-orphan")
    agent_decisions = relationship("AgentDecision", back_populates="transaction", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="transaction", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="transaction", cascade="all, delete-orphan")
