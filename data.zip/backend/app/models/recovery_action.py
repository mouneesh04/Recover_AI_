from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class RecoveryAction(Base):
    __tablename__ = "recovery_actions"

    id = Column(String(50), primary_key=True, index=True) # e.g. "ACT-1001"
    transaction_id = Column(String(50), ForeignKey("transactions.id"), nullable=False, index=True)
    
    # Action type: RETRY_NOW, RETRY_LATER, SEND_PAYMENT_REMINDER, SUGGEST_ALTERNATIVE_PAYMENT_METHOD, ESCALATE_TO_HUMAN, DO_NOT_RETRY
    action_type = Column(String(50), nullable=False)
    
    # Status: PENDING, EXECUTING, COMPLETED, FAILED, CANCELLED
    status = Column(String(30), default="PENDING", index=True)
    
    scheduled_for = Column(DateTime, nullable=True)
    executed_at = Column(DateTime, nullable=True)
    
    payload_json = Column(Text, nullable=True) # Stores parameters like delay_minutes, channels, etc.
    execution_summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    transaction = relationship("Transaction", back_populates="recovery_actions")
    results = relationship("RecoveryResult", back_populates="action", cascade="all, delete-orphan")
