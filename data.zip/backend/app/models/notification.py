from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(50), primary_key=True, index=True) # e.g. "NOTIF-1001"
    transaction_id = Column(String(50), ForeignKey("transactions.id"), nullable=False, index=True)
    customer_id = Column(String(50), ForeignKey("customers.id"), nullable=False, index=True)
    
    channel = Column(String(30), default="SMS") # SMS, EMAIL, WHATSAPP
    template_type = Column(String(50), default="PAYMENT_REMINDER") # PAYMENT_REMINDER, ALTERNATIVE_METHOD, RECOVERY_SUCCESS
    recipient = Column(String(120), nullable=False)
    message_body = Column(Text, nullable=False)
    status = Column(String(30), default="SENT") # PENDING, SENT, FAILED
    
    sent_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    transaction = relationship("Transaction", back_populates="notifications")
    customer = relationship("Customer", back_populates="notifications")
