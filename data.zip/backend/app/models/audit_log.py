from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(50), primary_key=True, index=True) # e.g. "AUD-1001"
    actor = Column(String(30), nullable=False) # SYSTEM, AI_AGENT, MERCHANT
    action = Column(String(100), nullable=False) # e.g. "ANALYZE_FAILURE", "EXECUTE_RETRY", "APPROVE_RECOVERY"
    
    entity_type = Column(String(50), default="TRANSACTION") # TRANSACTION, CUSTOMER, ACTION
    entity_id = Column(String(50), ForeignKey("transactions.id"), nullable=True, index=True)
    
    reason = Column(Text, nullable=True)
    details_json = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    transaction = relationship("Transaction", back_populates="audit_logs")
