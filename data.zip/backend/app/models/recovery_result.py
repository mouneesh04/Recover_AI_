from sqlalchemy import Column, String, Float, Integer, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.app.database.connection import Base

class RecoveryResult(Base):
    __tablename__ = "recovery_results"

    id = Column(String(50), primary_key=True, index=True) # e.g. "RES-1001"
    transaction_id = Column(String(50), ForeignKey("transactions.id"), nullable=False, index=True)
    action_id = Column(String(50), ForeignKey("recovery_actions.id"), nullable=True, index=True)
    
    # Outcome: SUCCESS, FAILED, TIMEOUT, DECLINED, INSUFFICIENT_FUNDS
    outcome = Column(String(30), nullable=False)
    recovered_amount = Column(Float, default=0.0)
    latency_ms = Column(Integer, default=0)
    gateway_response = Column(Text, nullable=True) # Raw gateway simulator response JSON
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    transaction = relationship("Transaction", back_populates="recovery_results")
    action = relationship("RecoveryAction", back_populates="results")
