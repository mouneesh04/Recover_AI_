import uuid
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.models.notification import Notification
from backend.app.models.audit_log import AuditLog
from backend.app.ml.classifier import classify_failure
from backend.app.ml.inference import predictor
from backend.app.simulator.payment_gateway import gateway_simulator

class AgentToolRegistry:
    """
    Registry of tools callable by the Autonomous Recovery Agent.
    Every tool interacts directly with the database, ML engine, or simulator.
    """

    @staticmethod
    def get_transaction(transaction_id: str, db: Session) -> Dict[str, Any]:
        """Tool: Retrieves current transaction record and metadata."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if not txn:
            return {"error": f"Transaction {transaction_id} not found."}
            
        return {
            "id": txn.id,
            "customer_id": txn.customer_id,
            "amount": txn.amount,
            "currency": txn.currency,
            "payment_method": txn.payment_method,
            "status": txn.status,
            "failure_reason": txn.failure_reason,
            "failure_code": txn.failure_code,
            "retry_count": txn.retry_count,
            "max_retries": txn.max_retries,
            "device_type": txn.device_type,
            "ip_location": txn.ip_location,
            "network_latency_ms": txn.network_latency_ms,
            "bank_response_time_ms": txn.bank_response_time_ms,
            "recovery_probability": txn.recovery_probability,
            "recommended_strategy": txn.recommended_strategy
        }

    @staticmethod
    def get_customer_history(customer_id: str, db: Session) -> Dict[str, Any]:
        """Tool: Retrieves customer spending profile and payment success statistics."""
        customer = db.query(Customer).filter(Customer.id == customer_id).first()
        if not customer:
            return {
                "customer_id": customer_id,
                "name": "Guest Customer",
                "email": "guest@example.com",
                "tier": "STANDARD",
                "total_transactions": 1,
                "successful_transactions": 1,
                "failed_transactions": 0,
                "historical_success_rate": 1.0,
                "avg_transaction_amount": 1000.0
            }
            
        return {
            "customer_id": customer.id,
            "name": customer.name,
            "email": customer.email,
            "phone": customer.phone,
            "tier": customer.tier,
            "total_transactions": customer.total_transactions,
            "successful_transactions": customer.successful_transactions,
            "failed_transactions": customer.failed_transactions,
            "historical_success_rate": customer.historical_success_rate,
            "avg_transaction_amount": customer.avg_transaction_amount,
            "last_payment_at": str(customer.last_payment_at) if customer.last_payment_at else None
        }

    @staticmethod
    def analyze_failure(failure_reason: str, failure_code: Optional[str] = None) -> Dict[str, Any]:
        """Tool: Classifies the failure and provides diagnostic category."""
        return classify_failure(failure_reason, failure_code)

    @staticmethod
    def predict_recovery(txn_dict: Dict[str, Any], cust_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Tool: Evaluates ML recoverability model and generates explainability factors."""
        return predictor.predict(txn_dict, cust_dict)

    @staticmethod
    def retry_payment(
        transaction_id: str,
        amount: float,
        payment_method: str,
        failure_reason: str,
        retry_count: int,
        db: Session,
        test_seed: Optional[int] = None
    ) -> Dict[str, Any]:
        """Tool: Executes payment retry through the payment gateway simulator."""
        # 1. Create RecoveryAction record
        action_id = f"ACT-{uuid.uuid4().hex[:8].upper()}"
        action = RecoveryAction(
            id=action_id,
            transaction_id=transaction_id,
            action_type="RETRY_NOW",
            status="EXECUTING",
            executed_at=datetime.utcnow(),
            payload_json=json.dumps({"payment_method": payment_method, "retry_attempt": retry_count + 1})
        )
        db.add(action)
        db.commit()

        # 2. Call gateway simulator
        sim_res = gateway_simulator.process_retry(
            transaction_id=transaction_id,
            amount=amount,
            payment_method=payment_method,
            failure_reason=failure_reason,
            retry_count=retry_count,
            test_seed=test_seed
        )

        outcome = sim_res.get("status", "FAILED")
        rec_amount = amount if outcome == "SUCCESS" else 0.0

        # 3. Create RecoveryResult record
        result_id = f"RES-{uuid.uuid4().hex[:8].upper()}"
        rec_result = RecoveryResult(
            id=result_id,
            transaction_id=transaction_id,
            action_id=action_id,
            outcome=outcome,
            recovered_amount=rec_amount,
            latency_ms=sim_res.get("latency_ms", 150),
            gateway_response=json.dumps(sim_res)
        )
        action.status = "COMPLETED"
        action.execution_summary = f"Retry executed with outcome: {outcome} ({sim_res.get('message', '')})"
        
        # 4. Update Transaction record
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if txn:
            txn.retry_count += 1
            if outcome == "SUCCESS":
                txn.status = "RECOVERED"
                txn.recovered_at = datetime.utcnow()
                
                # Update customer stats
                cust = db.query(Customer).filter(Customer.id == txn.customer_id).first()
                if cust:
                    cust.successful_transactions += 1
                    cust.total_transactions += 1
                    cust.last_payment_at = datetime.utcnow()
                    cust.historical_success_rate = round(cust.successful_transactions / max(1, cust.total_transactions), 3)
            else:
                if txn.retry_count >= txn.max_retries:
                    txn.status = "NON_RECOVERABLE"
                else:
                    txn.status = "FAILED"

        db.add(rec_result)
        db.commit()

        return {
            "action_id": action_id,
            "result_id": result_id,
            "outcome": outcome,
            "recovered_amount": rec_amount,
            "gateway_response": sim_res
        }

    @staticmethod
    def schedule_retry(
        transaction_id: str,
        delay_minutes: int,
        db: Session
    ) -> Dict[str, Any]:
        """Tool: Schedules a deferred retry action (e.g. after bank maintenance window)."""
        action_id = f"ACT-SCHED-{uuid.uuid4().hex[:8].upper()}"
        sched_time = datetime.utcnow() + timedelta(minutes=delay_minutes)
        
        action = RecoveryAction(
            id=action_id,
            transaction_id=transaction_id,
            action_type="RETRY_LATER",
            status="PENDING",
            scheduled_for=sched_time,
            payload_json=json.dumps({"delay_minutes": delay_minutes}),
            execution_summary=f"Deferred retry scheduled in {delay_minutes} minutes."
        )
        
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if txn:
            txn.status = "RECOVERING"
            
        db.add(action)
        db.commit()
        
        return {
            "action_id": action_id,
            "scheduled_for": str(sched_time),
            "delay_minutes": delay_minutes,
            "status": "PENDING"
        }

    @staticmethod
    def send_payment_reminder(
        transaction_id: str,
        customer_id: str,
        channel: str,
        db: Session
    ) -> Dict[str, Any]:
        """Tool: Generates and dispatches an automated customer payment reminder notification."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        cust = db.query(Customer).filter(Customer.id == customer_id).first()
        
        amount_str = f"₹{txn.amount:,.2f}" if txn else "your order"
        recipient = cust.phone if (channel == "SMS" and cust and cust.phone) else (cust.email if cust else "customer@example.com")
        
        message_body = (
            f"RecoverAI Notice: Your payment of {amount_str} was interrupted due to a temporary bank issue. "
            f"Click here to instantly complete your order with 1-click retry: https://pay.recoverai.demo/{transaction_id}"
        )
        
        notif_id = f"NOTIF-{uuid.uuid4().hex[:8].upper()}"
        notif = Notification(
            id=notif_id,
            transaction_id=transaction_id,
            customer_id=customer_id,
            channel=channel,
            template_type="PAYMENT_REMINDER",
            recipient=recipient,
            message_body=message_body,
            status="SENT",
            sent_at=datetime.utcnow()
        )
        
        action_id = f"ACT-NOTIF-{uuid.uuid4().hex[:8].upper()}"
        action = RecoveryAction(
            id=action_id,
            transaction_id=transaction_id,
            action_type="SEND_PAYMENT_REMINDER",
            status="COMPLETED",
            executed_at=datetime.utcnow(),
            payload_json=json.dumps({"channel": channel, "recipient": recipient}),
            execution_summary=f"Payment reminder sent via {channel} to {recipient}."
        )
        
        if txn:
            txn.status = "RECOVERING"
            
        db.add(notif)
        db.add(action)
        db.commit()
        
        return {
            "notification_id": notif_id,
            "action_id": action_id,
            "channel": channel,
            "recipient": recipient,
            "message_body": message_body,
            "status": "SENT"
        }

    @staticmethod
    def suggest_alternative_payment(
        transaction_id: str,
        customer_id: str,
        db: Session
    ) -> Dict[str, Any]:
        """Tool: Generates smart fallback payment link offering alternate rails (UPI/Cards)."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        cust = db.query(Customer).filter(Customer.id == customer_id).first()
        
        amount = txn.amount if txn else 1000.0
        email = cust.email if cust else "customer@example.com"
        
        link_info = gateway_simulator.generate_alternative_payment_link(transaction_id, amount, email)
        
        action_id = f"ACT-ALT-{uuid.uuid4().hex[:8].upper()}"
        action = RecoveryAction(
            id=action_id,
            transaction_id=transaction_id,
            action_type="SUGGEST_ALTERNATIVE_PAYMENT_METHOD",
            status="COMPLETED",
            executed_at=datetime.utcnow(),
            payload_json=json.dumps(link_info),
            execution_summary=f"Smart recovery link generated: {link_info['checkout_url']}"
        )
        
        notif_id = f"NOTIF-{uuid.uuid4().hex[:8].upper()}"
        notif = Notification(
            id=notif_id,
            transaction_id=transaction_id,
            customer_id=customer_id,
            channel="EMAIL",
            template_type="ALTERNATIVE_METHOD",
            recipient=email,
            message_body=f"Your card declined for ₹{amount:,.2f}. Try paying securely via UPI or Netbanking: {link_info['checkout_url']}",
            status="SENT"
        )
        
        if txn:
            txn.status = "RECOVERING"
            
        db.add(action)
        db.add(notif)
        db.commit()
        
        return {
            "action_id": action_id,
            "notification_id": notif_id,
            "payment_link": link_info
        }

    @staticmethod
    def escalate_to_human(
        transaction_id: str,
        reason: str,
        db: Session
    ) -> Dict[str, Any]:
        """Tool: Routes transaction to the merchant's Human Review Queue."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if txn:
            txn.status = "MANUAL_REVIEW"
            
        action_id = f"ACT-ESC-{uuid.uuid4().hex[:8].upper()}"
        action = RecoveryAction(
            id=action_id,
            transaction_id=transaction_id,
            action_type="ESCALATE_TO_HUMAN",
            status="PENDING",
            payload_json=json.dumps({"reason": reason}),
            execution_summary=f"Escalated for human operator review: {reason}"
        )
        
        audit_id = f"AUD-{uuid.uuid4().hex[:8].upper()}"
        audit = AuditLog(
            id=audit_id,
            actor="AI_AGENT",
            action="ESCALATE_TO_HUMAN",
            entity_type="TRANSACTION",
            entity_id=transaction_id,
            reason=reason,
            details_json=json.dumps({"status": "MANUAL_REVIEW"})
        )
        
        db.add(action)
        db.add(audit)
        db.commit()
        
        return {
            "action_id": action_id,
            "status": "MANUAL_REVIEW",
            "reason": reason
        }

    @staticmethod
    def record_audit(
        actor: str,
        action: str,
        entity_id: str,
        reason: str,
        details: Dict[str, Any],
        db: Session
    ) -> str:
        """Tool: Persists an immutable audit log entry."""
        audit_id = f"AUD-{uuid.uuid4().hex[:8].upper()}"
        audit = AuditLog(
            id=audit_id,
            actor=actor,
            action=action,
            entity_type="TRANSACTION",
            entity_id=entity_id,
            reason=reason,
            details_json=json.dumps(details)
        )
        db.add(audit)
        db.commit()
        return audit_id
