from dataclasses import dataclass
from typing import Optional
from backend.app.config import settings

@dataclass
class PolicyCheckResult:
    is_safe: bool
    requires_human_approval: bool
    reason: str
    rejection_code: Optional[str] = None

class SafetyPolicyEngine:
    """
    Enforces deterministic financial safety guardrails for the Autonomous Recovery Agent.
    Prevents unauthorized high-value charges, infinite retry loops, and unverified actions.
    """
    
    @staticmethod
    def evaluate(
        amount: float,
        retry_count: int,
        recovery_probability: float,
        current_status: str,
        failure_reason: str
    ) -> PolicyCheckResult:
        # 1. Check if already recovered or terminal
        if current_status == "RECOVERED":
            return PolicyCheckResult(
                is_safe=False,
                requires_human_approval=False,
                reason="Transaction is already in RECOVERED state. No further action needed.",
                rejection_code="ALREADY_RECOVERED"
            )
            
        if current_status == "NON_RECOVERABLE":
            return PolicyCheckResult(
                is_safe=False,
                requires_human_approval=False,
                reason="Transaction is permanently marked as NON_RECOVERABLE.",
                rejection_code="PERMANENTLY_FAILED"
            )
            
        # 2. Check maximum retry attempts limit
        if retry_count >= settings.MAX_RETRY_ATTEMPTS:
            return PolicyCheckResult(
                is_safe=False,
                requires_human_approval=True,
                reason=f"Maximum retry limit ({settings.MAX_RETRY_ATTEMPTS}) reached. Escalating to human operator.",
                rejection_code="MAX_RETRIES_EXCEEDED"
            )
            
        # 3. Check high value transaction threshold
        if amount > settings.AUTO_RECOVERY_MAX_AMOUNT:
            return PolicyCheckResult(
                is_safe=False,
                requires_human_approval=True,
                reason=f"Transaction amount (₹{amount:,.2f}) exceeds automated threshold (₹{settings.AUTO_RECOVERY_MAX_AMOUNT:,.2f}). Human review required.",
                rejection_code="HIGH_VALUE_THRESHOLD"
            )
            
        # 4. Check confidence threshold
        if recovery_probability < settings.MIN_RECOVERY_CONFIDENCE:
            return PolicyCheckResult(
                is_safe=False,
                requires_human_approval=True,
                reason=f"Recovery confidence ({recovery_probability*100:.1f}%) is below minimum threshold ({settings.MIN_RECOVERY_CONFIDENCE*100:.1f}%). Automated retry aborted.",
                rejection_code="LOW_CONFIDENCE"
            )
            
        # Passed all safety checks
        return PolicyCheckResult(
            is_safe=True,
            requires_human_approval=False,
            reason="All autonomous safety guardrails satisfied. Automated execution approved."
        )

policy_engine = SafetyPolicyEngine()
