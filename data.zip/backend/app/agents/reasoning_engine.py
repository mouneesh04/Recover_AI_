import os
import json
from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from backend.app.config import settings

class StructuredAgentDecision(BaseModel):
    transaction_id: str
    decision: str
    confidence: float
    reason: str
    delay_minutes: int = 0
    requires_human_approval: bool = False
    next_step: str
    factors: List[Dict[str, Any]] = Field(default_factory=list)

class AgentReasoningEngine:
    """
    Reasoning engine that combines ML probability scores, customer context,
    and safety policies to synthesize a structured JSON decision.
    """

    @classmethod
    def reason(
        cls,
        transaction: Dict[str, Any],
        customer: Dict[str, Any],
        ml_prediction: Dict[str, Any],
        policy_result: Any
    ) -> StructuredAgentDecision:
        txn_id = transaction.get("id", "UNKNOWN")
        amount = float(transaction.get("amount", 0.0))
        prob = float(ml_prediction.get("recovery_probability", 0.5))
        failure_classification = ml_prediction.get("failure_classification", {})
        failure_reason = failure_classification.get("failure_reason", "UNKNOWN")
        retry_count = int(transaction.get("retry_count", 0))
        succ_rate = float(customer.get("historical_success_rate", 0.8))
        
        # Check safety guardrails first
        if policy_result.requires_human_approval:
            return StructuredAgentDecision(
                transaction_id=txn_id,
                decision="ESCALATE_TO_HUMAN",
                confidence=prob,
                reason=policy_result.reason,
                delay_minutes=0,
                requires_human_approval=True,
                next_step="ROUTE_TO_HUMAN_REVIEW",
                factors=ml_prediction.get("key_factors", [])
            )
            
        # Select strategy
        strategy = ml_prediction.get("recommended_strategy", "RETRY_LATER")
        
        # Build contextual rationale
        if strategy == "RETRY_LATER":
            delay = 15
            reason = (
                f"Failure classified as transient {failure_reason.replace('_', ' ').lower()}. "
                f"Customer has a {succ_rate*100:.0f}% historical success rate. "
                f"Scheduling automatic retry in {delay} minutes allows bank switches to recover."
            )
            next_step = "SCHEDULE_RETRY"
        elif strategy == "RETRY_NOW":
            delay = 0
            reason = (
                f"Failure was a transient network or gateway glitch on attempt #{retry_count + 1}. "
                f"Immediate retry offers high probability ({prob*100:.0f}%) of successful capture."
            )
            next_step = "EXECUTE_RETRY_NOW"
        elif strategy == "SEND_PAYMENT_REMINDER":
            delay = 0
            reason = (
                f"Failure due to {failure_reason.replace('_', ' ').lower()}. "
                f"Dispatching a personalized reminder with 1-click checkout link."
            )
            next_step = "DISPATCH_NOTIFICATION"
        elif strategy == "SUGGEST_ALTERNATIVE_PAYMENT_METHOD":
            delay = 0
            reason = (
                f"Payment method issue detected ({failure_reason.replace('_', ' ').lower()}). "
                f"Generated smart alternative checkout link offering UPI and alternate rails."
            )
            next_step = "GENERATE_SMART_PAYLINK"
        else:
            delay = 0
            reason = "Payment parameters indicate low probability of recovery. Ceasing automated retries."
            next_step = "MARK_TERMINAL"
            
        return StructuredAgentDecision(
            transaction_id=txn_id,
            decision=strategy,
            confidence=prob,
            reason=reason,
            delay_minutes=delay,
            requires_human_approval=False,
            next_step=next_step,
            factors=ml_prediction.get("key_factors", [])
        )
