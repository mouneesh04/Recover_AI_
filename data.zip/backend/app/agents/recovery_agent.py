import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from backend.app.agents.state import AgentState
from backend.app.agents.tools import AgentToolRegistry
from backend.app.agents.policies import policy_engine
from backend.app.agents.reasoning_engine import AgentReasoningEngine
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.transaction import Transaction

class AutonomousRecoveryAgent:
    """
    Core Autonomous AI Recovery Agent for RecoverAI.
    Executes a closed ReAct loop: Observe -> Reason -> Policy Guard -> Tool Act -> Observe Result.
    """

    def __init__(self, db: Session):
        self.db = db
        self.tools = AgentToolRegistry()

    def run_recovery_loop(
        self,
        transaction_id: str,
        test_seed: Optional[int] = None
    ) -> AgentState:
        """
        Runs the end-to-end autonomous recovery workflow for a single transaction.
        """
        # Step 1: Ingest and fetch transaction context
        txn_data = self.tools.get_transaction(transaction_id, self.db)
        if "error" in txn_data:
            state = AgentState(
                transaction_id=transaction_id,
                amount=0.0,
                customer_id="UNKNOWN",
                is_terminal=True,
                final_outcome="NOT_FOUND",
                reasoning_text=txn_data["error"]
            )
            return state

        # Initialize State
        state = AgentState(
            transaction_id=txn_data["id"],
            amount=txn_data["amount"],
            currency=txn_data["currency"],
            customer_id=txn_data["customer_id"],
            current_status=txn_data["status"]
        )
        state.add_tool_log("get_transaction", {"transaction_id": transaction_id}, txn_data)

        # Step 2: Retrieve Customer Profile & History
        cust_data = self.tools.get_customer_history(txn_data["customer_id"], self.db)
        state.customer_history = cust_data
        state.add_tool_log("get_customer_history", {"customer_id": txn_data["customer_id"]}, cust_data)

        # Step 3: Analyze Failure
        failure_diag = self.tools.analyze_failure(txn_data["failure_reason"], txn_data["failure_code"])
        state.failure_classification = failure_diag
        state.add_tool_log("analyze_failure", {"reason": txn_data["failure_reason"]}, failure_diag)

        # Step 4: ML Recoverability Prediction & Explainability
        prediction = self.tools.predict_recovery(txn_data, cust_data)
        state.recovery_probability = prediction["recovery_probability"]
        state.risk_level = prediction["risk_level"]
        state.factors = prediction["key_factors"]
        state.add_tool_log("predict_recovery", {"features": "extracted"}, prediction)

        # Step 5: Evaluate Safety Policies & Guardrails
        policy_res = policy_engine.evaluate(
            amount=state.amount,
            retry_count=txn_data["retry_count"],
            recovery_probability=state.recovery_probability,
            current_status=txn_data["status"],
            failure_reason=txn_data["failure_reason"]
        )
        state.requires_human_approval = policy_res.requires_human_approval
        state.policy_evaluation = {
            "is_safe": policy_res.is_safe,
            "requires_human_approval": policy_res.requires_human_approval,
            "reason": policy_res.reason,
            "rejection_code": policy_res.rejection_code
        }

        # Step 6: Formulate Structured Agent Decision
        decision = AgentReasoningEngine.reason(
            transaction=txn_data,
            customer=cust_data,
            ml_prediction=prediction,
            policy_result=policy_res
        )
        state.strategy_chosen = decision.decision
        state.reasoning_text = decision.reason

        # Persist Agent Decision in Database
        decision_id = f"DEC-{uuid.uuid4().hex[:8].upper()}"
        agent_decision_row = AgentDecision(
            id=decision_id,
            transaction_id=transaction_id,
            step_number=state.step_number,
            strategy_chosen=decision.decision,
            confidence=decision.confidence,
            reasoning_text=decision.reason,
            factors_json=json.dumps(decision.factors),
            requires_human_approval=decision.requires_human_approval,
            approval_status="PENDING_APPROVAL" if decision.requires_human_approval else "AUTO_APPROVED",
            tool_calls_log=json.dumps([t.model_dump() for t in state.tool_history], default=str)
        )
        self.db.add(agent_decision_row)
        
        # Update transaction metadata
        txn_record = self.db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if txn_record:
            txn_record.recovery_probability = state.recovery_probability
            txn_record.recommended_strategy = decision.decision
            txn_record.risk_level = state.risk_level
            
        self.db.commit()

        # Step 7: Execute Tool Actions (if approved)
        if decision.requires_human_approval:
            # Route to Human Review Queue
            esc_res = self.tools.escalate_to_human(
                transaction_id=transaction_id,
                reason=policy_res.reason,
                db=self.db
            )
            state.add_tool_log("escalate_to_human", {"reason": policy_res.reason}, esc_res)
            state.is_terminal = True
            state.final_outcome = "MANUAL_REVIEW_REQUIRED"
            self.tools.record_audit(
                actor="AI_AGENT",
                action="ROUTE_TO_HUMAN_REVIEW",
                entity_id=transaction_id,
                reason=policy_res.reason,
                details={"strategy": decision.decision, "amount": state.amount},
                db=self.db
            )
            return state

        # If automated execution is approved:
        if decision.decision in ["RETRY_NOW", "RETRY_LATER"]:
            # Execute payment retry
            retry_res = self.tools.retry_payment(
                transaction_id=transaction_id,
                amount=state.amount,
                payment_method=txn_data["payment_method"],
                failure_reason=txn_data["failure_reason"],
                retry_count=txn_data["retry_count"],
                db=self.db,
                test_seed=test_seed
            )
            state.add_tool_log("retry_payment", {"method": txn_data["payment_method"]}, retry_res)
            
            outcome = retry_res.get("outcome", "FAILED")
            if outcome == "SUCCESS":
                state.is_terminal = True
                state.final_outcome = "RECOVERED"
                state.recovered_amount = state.amount
                self.tools.record_audit(
                    actor="AI_AGENT",
                    action="PAYMENT_RECOVERED",
                    entity_id=transaction_id,
                    reason=f"Payment recovered successfully on retry ({decision.decision}).",
                    details=retry_res,
                    db=self.db
                )
            else:
                # Retry failed; check if we should escalate or notify
                if txn_data["retry_count"] + 1 >= txn_data["max_retries"]:
                    self.tools.escalate_to_human(transaction_id, "Max automated retry limit reached after failure.", self.db)
                    state.is_terminal = True
                    state.final_outcome = "NON_RECOVERABLE"
                else:
                    state.is_terminal = False
                    state.final_outcome = "RETRY_FAILED"
                    
        elif decision.decision == "SEND_PAYMENT_REMINDER":
            remind_res = self.tools.send_payment_reminder(
                transaction_id=transaction_id,
                customer_id=txn_data["customer_id"],
                channel="SMS" if cust_data.get("phone") else "EMAIL",
                db=self.db
            )
            state.add_tool_log("send_payment_reminder", {"channel": "SMS"}, remind_res)
            state.is_terminal = False
            state.final_outcome = "REMINDER_SENT"
            self.tools.record_audit(
                actor="AI_AGENT",
                action="SEND_REMINDER",
                entity_id=transaction_id,
                reason="Dispatched payment recovery link via customer communication channel.",
                details=remind_res,
                db=self.db
            )
            
        elif decision.decision == "SUGGEST_ALTERNATIVE_PAYMENT_METHOD":
            alt_res = self.tools.suggest_alternative_payment(
                transaction_id=transaction_id,
                customer_id=txn_data["customer_id"],
                db=self.db
            )
            state.add_tool_log("suggest_alternative_payment", {}, alt_res)
            state.is_terminal = False
            state.final_outcome = "ALTERNATIVE_LINK_GENERATED"
            self.tools.record_audit(
                actor="AI_AGENT",
                action="GENERATE_ALT_LINK",
                entity_id=transaction_id,
                reason="Created fallback checkout link with alternate payment options.",
                details=alt_res,
                db=self.db
            )
            
        else:
            state.is_terminal = True
            state.final_outcome = "DO_NOT_RETRY"
            self.tools.record_audit(
                actor="AI_AGENT",
                action="ABORT_RECOVERY",
                entity_id=transaction_id,
                reason="Payment evaluated as unrecoverable.",
                details={"confidence": decision.confidence},
                db=self.db
            )

        return state
