from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from datetime import datetime

class ToolInvocationLog(BaseModel):
    tool_name: str
    arguments: Dict[str, Any]
    output: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class AgentState(BaseModel):
    transaction_id: str
    step_number: int = 1
    current_status: str = "FAILED"
    amount: float
    currency: str = "INR"
    customer_id: str
    customer_history: Optional[Dict[str, Any]] = None
    failure_classification: Optional[Dict[str, Any]] = None
    recovery_probability: Optional[float] = None
    risk_level: Optional[str] = None
    strategy_chosen: Optional[str] = None
    reasoning_text: Optional[str] = None
    factors: List[Dict[str, Any]] = Field(default_factory=list)
    requires_human_approval: bool = False
    policy_evaluation: Optional[Dict[str, Any]] = None
    tool_history: List[ToolInvocationLog] = Field(default_factory=list)
    is_terminal: bool = False
    final_outcome: Optional[str] = None
    recovered_amount: float = 0.0

    def add_tool_log(self, tool_name: str, arguments: Dict[str, Any], output: Dict[str, Any]):
        self.tool_history.append(
            ToolInvocationLog(tool_name=tool_name, arguments=arguments, output=output)
        )
