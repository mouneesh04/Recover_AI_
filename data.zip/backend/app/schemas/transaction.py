from pydantic import BaseModel, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime

class TransactionBase(BaseModel):
    customer_id: str
    amount: float
    currency: str = "INR"
    payment_method: str
    failure_reason: Optional[str] = None
    device_type: Optional[str] = "MOBILE"
    ip_location: Optional[str] = "Mumbai, IN"

class TransactionCreate(TransactionBase):
    id: Optional[str] = None

class TransactionRead(TransactionBase):
    id: str
    status: str
    failure_code: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    recovery_probability: Optional[float] = None
    risk_level: Optional[str] = "LOW"
    recommended_strategy: Optional[str] = None
    network_latency_ms: Optional[int] = 120
    bank_response_time_ms: Optional[int] = 750
    failed_at: Optional[datetime] = None
    recovered_at: Optional[datetime] = None
    created_at: datetime
    customer_name: Optional[str] = None
    customer_email: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class TransactionListResponse(BaseModel):
    items: List[TransactionRead]
    total: int
    page: int
    page_size: int
    total_pages: int

class TimelineEvent(BaseModel):
    step: int
    timestamp: datetime
    title: str
    description: str
    type: str
    status: str
    metadata: Optional[Dict[str, Any]] = None

class TransactionTimelineResponse(BaseModel):
    transaction_id: str
    current_status: str
    events: List[TimelineEvent]

class AnalyzeResponse(BaseModel):
    transaction_id: str
    recovery_probability: float
    recoverable: bool
    risk_level: str
    recommended_strategy: str
    explanation_summary: str
    key_factors: List[Dict[str, Any]]
    positive_drivers: List[str]
    negative_drivers: List[str]
