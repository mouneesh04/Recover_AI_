from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class StrategyROI(BaseModel):
    strategy: str
    attempted_count: int
    success_count: int
    success_rate: float
    revenue_recovered: float
    avg_recovery_time_mins: float

class LatencyBucket(BaseModel):
    range: str
    failure_count: int
    recovery_rate: float

class AnalyticsResponse(BaseModel):
    strategy_roi: List[StrategyROI]
    recovery_by_amount_tier: List[Dict[str, Any]]
    recovery_by_customer_type: List[Dict[str, Any]]
    failure_recovery_matrix: List[Dict[str, Any]]
    ml_model_metrics: Dict[str, Any]
