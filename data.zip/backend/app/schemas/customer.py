from pydantic import BaseModel, ConfigDict
from typing import Optional, List, Any
from datetime import datetime

class CustomerBase(BaseModel):
    id: str
    name: str
    email: str
    phone: Optional[str] = None
    tier: str = "STANDARD"

class CustomerRead(CustomerBase):
    total_transactions: int = 0
    successful_transactions: int = 0
    failed_transactions: int = 0
    historical_success_rate: float = 1.0
    avg_transaction_amount: float = 0.0
    last_payment_at: Optional[datetime] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class CustomerDetail(CustomerRead):
    recent_transactions: List[Any] = []
