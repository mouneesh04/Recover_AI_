from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class MetricSummary(BaseModel):
    total_transactions: int
    successful_transactions: int
    failed_transactions: int
    recoverable_failed_transactions: int
    recovered_count: int
    recovery_rate_pct: float
    revenue_at_risk: float
    revenue_recovered: float
    pending_recovery_actions: int
    human_review_cases: int
    currency: str = "INR"

class ChartDataPoint(BaseModel):
    date: str
    failed_count: int
    recovered_count: int
    revenue_at_risk: float
    revenue_recovered: float
    recovery_rate: float

class CategoryBreakdown(BaseModel):
    name: str
    count: int
    percentage: float
    recovered_count: Optional[int] = 0
    revenue_recovered: Optional[float] = 0.0

class DashboardMetricsResponse(BaseModel):
    metrics: MetricSummary
    timeseries: List[ChartDataPoint]
    failure_reasons: List[CategoryBreakdown]
    payment_methods: List[CategoryBreakdown]
    recovery_strategies: List[CategoryBreakdown]
