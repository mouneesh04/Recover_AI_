from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime

class HumanReviewItem(BaseModel):
    id: str # Transaction ID
    customer_id: str
    customer_name: str
    customer_tier: str
    amount: float
    currency: str
    payment_method: str
    failure_reason: str
    retry_count: int
    recovery_probability: float
    recommended_strategy: str
    escalation_reason: str
    risk_level: str
    created_at: datetime
    factors: List[Dict[str, Any]] = []

class ApproveActionRequest(BaseModel):
    custom_strategy: Optional[str] = None # Optional override strategy
    notes: Optional[str] = None

class RejectActionRequest(BaseModel):
    reason: str
