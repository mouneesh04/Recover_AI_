from pydantic import BaseModel, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime

class AgentDecisionRead(BaseModel):
    id: str
    transaction_id: str
    step_number: int
    strategy_chosen: str
    confidence: float
    reasoning_text: str
    factors: List[Dict[str, Any]] = []
    requires_human_approval: bool
    approval_status: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class AgentActivityEvent(BaseModel):
    id: str
    timestamp: datetime
    transaction_id: str
    customer_name: Optional[str] = None
    event_type: str
    headline: str
    detail: str
    impact_amount: Optional[float] = None
    recovery_probability: Optional[float] = None
    strategy: Optional[str] = None
    badge_type: str
