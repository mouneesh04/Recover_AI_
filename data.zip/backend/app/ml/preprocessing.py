import numpy as np
import pandas as pd
from typing import Tuple, List, Dict, Any

CATEGORICAL_COLS = ["payment_method", "device_type", "failure_reason"]
NUMERIC_COLS = [
    "amount",
    "hour",
    "day_of_week",
    "customer_age_days",
    "previous_transactions",
    "previous_successful_transactions",
    "previous_failed_transactions",
    "previous_success_rate",
    "average_transaction_amount",
    "amount_deviation",
    "retry_count",
    "time_since_last_transaction_hours",
    "is_first_transaction",
    "network_latency_ms",
    "bank_response_time_ms",
    "historical_recovery_rate"
]

ALL_FEATURE_COLS = NUMERIC_COLS + CATEGORICAL_COLS

def prepare_features(df: pd.DataFrame, is_training: bool = False, feature_columns: List[str] = None) -> Tuple[pd.DataFrame, List[str]]:
    """
    Transforms raw transaction records into a one-hot encoded numeric feature matrix.
    """
    # Ensure missing numeric values are imputed
    df_clean = df.copy()
    for col in NUMERIC_COLS:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce").fillna(0.0)
        else:
            df_clean[col] = 0.0

    for col in CATEGORICAL_COLS:
        if col in df_clean.columns:
            df_clean[col] = df_clean[col].astype(str).fillna("UNKNOWN")
        else:
            df_clean[col] = "UNKNOWN"
            
    # One-hot encode categoricals
    df_encoded = pd.get_dummies(df_clean[ALL_FEATURE_COLS], columns=CATEGORICAL_COLS, drop_first=False)
    
    if is_training:
        cols = list(df_encoded.columns)
        return df_encoded, cols
    else:
        # Align columns with training feature set
        if feature_columns is None:
            raise ValueError("feature_columns must be provided for inference")
        for col in feature_columns:
            if col not in df_encoded.columns:
                df_encoded[col] = 0.0
        df_encoded = df_encoded[feature_columns]
        return df_encoded, feature_columns

def extract_features_from_dict(txn_dict: Dict[str, Any], cust_dict: Dict[str, Any] = None) -> pd.DataFrame:
    """
    Extracts unified feature dictionary from a single transaction + customer record.
    """
    cust_dict = cust_dict or {}
    
    total_txns = cust_dict.get("total_transactions", 1)
    succ_txns = cust_dict.get("successful_transactions", 1)
    fail_txns = cust_dict.get("failed_transactions", 0)
    succ_rate = cust_dict.get("historical_success_rate", 1.0)
    avg_amount = cust_dict.get("avg_transaction_amount", float(txn_dict.get("amount", 1000.0)))
    
    amount = float(txn_dict.get("amount", 1000.0))
    amount_deviation = round(amount / max(1.0, avg_amount), 3)
    
    row = {
        "amount": amount,
        "payment_method": str(txn_dict.get("payment_method", "CARD")).upper(),
        "device_type": str(txn_dict.get("device_type", "MOBILE")).upper(),
        "hour": int(txn_dict.get("hour", 14)),
        "day_of_week": int(txn_dict.get("day_of_week", 2)),
        "customer_age_days": int(cust_dict.get("customer_age_days", 120)),
        "previous_transactions": total_txns,
        "previous_successful_transactions": succ_txns,
        "previous_failed_transactions": fail_txns,
        "previous_success_rate": succ_rate,
        "average_transaction_amount": avg_amount,
        "amount_deviation": amount_deviation,
        "retry_count": int(txn_dict.get("retry_count", 0)),
        "time_since_last_transaction_hours": float(txn_dict.get("time_since_last_transaction_hours", 24.0)),
        "is_first_transaction": 1 if total_txns <= 1 else 0,
        "network_latency_ms": int(txn_dict.get("network_latency_ms", 120)),
        "bank_response_time_ms": int(txn_dict.get("bank_response_time_ms", 750)),
        "failure_reason": str(txn_dict.get("failure_reason", "UNKNOWN")).upper(),
        "historical_recovery_rate": float(txn_dict.get("historical_recovery_rate", 0.75))
    }
    
    return pd.DataFrame([row])
