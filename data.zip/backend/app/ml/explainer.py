from typing import Dict, Any, List
import pandas as pd
import numpy as np

def generate_merchant_explanation(
    features_df: pd.DataFrame,
    probability: float,
    strategy: str,
    top_n: int = 5
) -> Dict[str, Any]:
    """
    Generates human-readable, merchant-friendly explanations from model features
    and calculated probability.
    """
    if features_df.empty:
        return {
            "factors": ["Standard payment recovery analysis performed."],
            "positive_drivers": ["Standard recovery flow."],
            "negative_drivers": [],
            "risk_level": "LOW" if probability > 0.7 else ("MEDIUM" if probability > 0.4 else "HIGH")
        }
        
    row = features_df.iloc[0].to_dict()
    
    factors: List[Dict[str, Any]] = []
    positive_drivers: List[str] = []
    negative_drivers: List[str] = []
    
    # 1. Customer History Factor
    succ_rate = row.get("previous_success_rate", 1.0)
    total_txns = int(row.get("previous_transactions", 1))
    succ_txns = int(row.get("previous_successful_transactions", 1))
    
    if succ_rate >= 0.85 and total_txns >= 3:
        msg = f"Customer has strong payment history ({succ_txns}/{total_txns} successful payments, {succ_rate*100:.0f}% success rate)."
        positive_drivers.append(msg)
        factors.append({"factor": msg, "impact": "POSITIVE", "weight": "+18%"})
    elif succ_rate < 0.6:
        msg = f"Customer has lower historical payment reliability ({succ_rate*100:.0f}% success rate)."
        negative_drivers.append(msg)
        factors.append({"factor": msg, "impact": "NEGATIVE", "weight": "-15%"})
    else:
        msg = f"Customer has established payment profile with {total_txns} past transactions."
        factors.append({"factor": msg, "impact": "NEUTRAL", "weight": "+5%"})
        
    # 2. Failure Reason Factor
    failure_reason = str(row.get("failure_reason", "UNKNOWN")).upper()
    if failure_reason in ["BANK_TIMEOUT", "NETWORK_ERROR", "GATEWAY_ERROR"]:
        msg = f"Failure was classified as a temporary {failure_reason.replace('_', ' ').lower()}, which typically clears on retry."
        positive_drivers.append(msg)
        factors.append({"factor": msg, "impact": "POSITIVE", "weight": "+24%"})
    elif failure_reason in ["UPI_FAILURE"]:
        msg = "UPI PSP switch latency encountered; high probability of success on secondary attempt."
        positive_drivers.append(msg)
        factors.append({"factor": msg, "impact": "POSITIVE", "weight": "+19%"})
    elif failure_reason in ["INSUFFICIENT_FUNDS"]:
        msg = "Failure was due to insufficient funds; automated payment reminder is recommended."
        factors.append({"factor": msg, "impact": "NEUTRAL", "weight": "+8%"})
    elif failure_reason in ["CARD_EXPIRED", "INVALID_DETAILS"]:
        msg = f"Permanent card issue ({failure_reason.replace('_', ' ').lower()}); direct retry will fail without payment method update."
        negative_drivers.append(msg)
        factors.append({"factor": msg, "impact": "NEGATIVE", "weight": "-35%"})
    elif failure_reason in ["BANK_DECLINED"]:
        msg = "Bank actively declined transaction; alternative payment route recommended."
        negative_drivers.append(msg)
        factors.append({"factor": msg, "impact": "NEGATIVE", "weight": "-20%"})
        
    # 3. Retry Count Factor
    retry_count = int(row.get("retry_count", 0))
    if retry_count == 0:
        msg = "First recovery attempt (highest baseline statistical success rate)."
        positive_drivers.append(msg)
        factors.append({"factor": msg, "impact": "POSITIVE", "weight": "+15%"})
    elif retry_count == 1:
        msg = "Second recovery attempt (moderate recovery probability)."
        factors.append({"factor": msg, "impact": "NEUTRAL", "weight": "0%"})
    else:
        msg = f"Prior recovery attempts failed ({retry_count} previous attempts)."
        negative_drivers.append(msg)
        factors.append({"factor": msg, "impact": "NEGATIVE", "weight": "-22%"})
        
    # 4. Amount Deviation Factor
    amount = float(row.get("amount", 1000))
    amount_dev = float(row.get("amount_deviation", 1.0))
    if 0.7 <= amount_dev <= 1.3:
        msg = f"Transaction amount (₹{amount:,.2f}) matches customer's typical spending patterns."
        positive_drivers.append(msg)
        factors.append({"factor": msg, "impact": "POSITIVE", "weight": "+10%"})
    elif amount_dev > 2.5:
        msg = f"Transaction amount (₹{amount:,.2f}) is {amount_dev:.1f}x higher than customer's average spend."
        negative_drivers.append(msg)
        factors.append({"factor": msg, "impact": "NEGATIVE", "weight": "-12%"})
        
    # 5. Infrastructure Latency Factor
    bank_resp = int(row.get("bank_response_time_ms", 650))
    if bank_resp > 2500:
        msg = f"Bank server response time was unusually elevated ({bank_resp}ms), indicating transient gateway load."
        factors.append({"factor": msg, "impact": "NEUTRAL", "weight": "+6%"})
        
    # Determine Risk Level
    if probability >= 0.75:
        risk_level = "LOW"
    elif probability >= 0.45:
        risk_level = "MEDIUM"
    elif probability >= 0.20:
        risk_level = "HIGH"
    else:
        risk_level = "CRITICAL"
        
    # Summary string
    summary = f"Recovery probability estimated at {probability*100:.0f}%. "
    if positive_drivers:
        summary += f"Primary positive indicator: {positive_drivers[0]} "
    if negative_drivers:
        summary += f"Primary risk factor: {negative_drivers[0]}"
        
    return {
        "summary": summary,
        "risk_level": risk_level,
        "factors": factors[:top_n],
        "positive_drivers": positive_drivers,
        "negative_drivers": negative_drivers,
        "recommended_strategy": strategy
    }
