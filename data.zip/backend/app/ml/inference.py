import os
import json
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional

from backend.app.ml.preprocessing import extract_features_from_dict, prepare_features
from backend.app.ml.explainer import generate_merchant_explanation
from backend.app.ml.classifier import classify_failure

class RecoveryPredictor:
    """
    Production inference engine for RecoverAI.
    Loads the trained XGBoost model and feature mappings once into memory.
    """
    _instance: Optional["RecoveryPredictor"] = None
    
    def __init__(self, artifacts_dir: str = "ml/artifacts"):
        self.artifacts_dir = artifacts_dir
        self.model = None
        self.feature_columns = None
        self.load_model()
        
    @classmethod
    def get_instance(cls) -> "RecoveryPredictor":
        if cls._instance is None:
            cls._instance = RecoveryPredictor()
        return cls._instance

    def load_model(self):
        model_path = os.path.join(self.artifacts_dir, "xgboost_recovery_model.joblib")
        features_path = os.path.join(self.artifacts_dir, "feature_columns.json")
        
        if os.path.exists(model_path) and os.path.exists(features_path):
            try:
                self.model = joblib.load(model_path)
                with open(features_path, "r") as f:
                    self.feature_columns = json.load(f)
                print(f"[RecoverAI ML] Successfully loaded XGBoost model from {model_path}")
            except Exception as e:
                print(f"[RecoverAI ML] Warning: Could not load model: {e}")
                self.model = None
        else:
            print(f"[RecoverAI ML] Model artifacts not found at {model_path}. Using fallback predictor until trained.")
            self.model = None

    def predict(self, txn_dict: Dict[str, Any], cust_dict: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Executes model inference and returns structured recoverability metrics + explainability.
        """
        cust_dict = cust_dict or {}
        raw_reason = txn_dict.get("failure_reason", "UNKNOWN")
        classification = classify_failure(raw_reason)
        
        # Prepare input features dataframe
        raw_df = extract_features_from_dict(txn_dict, cust_dict)
        
        # 1. Model Inference
        if self.model is not None and self.feature_columns is not None:
            try:
                X_encoded, _ = prepare_features(raw_df, is_training=False, feature_columns=self.feature_columns)
                probability = float(self.model.predict_proba(X_encoded)[0, 1])
            except Exception as e:
                print(f"[RecoverAI ML] Inference error: {e}. Falling back to rule calculation.")
                probability = self._heuristic_probability(txn_dict, cust_dict, classification)
        else:
            probability = self._heuristic_probability(txn_dict, cust_dict, classification)
            
        probability = round(min(0.99, max(0.01, probability)), 4)
        recoverable = bool(probability >= 0.50)
        
        # 2. Strategy selection
        strategy = self._determine_strategy(txn_dict, probability, classification)
        
        # 3. Explainability & Factors
        explainability = generate_merchant_explanation(raw_df, probability, strategy)
        
        return {
            "recovery_probability": probability,
            "recoverable": recoverable,
            "recommended_strategy": strategy,
            "risk_level": explainability["risk_level"],
            "failure_classification": classification,
            "explanation_summary": explainability["summary"],
            "key_factors": explainability["factors"],
            "positive_drivers": explainability["positive_drivers"],
            "negative_drivers": explainability["negative_drivers"]
        }
        
    def _heuristic_probability(self, txn_dict: Dict[str, Any], cust_dict: Dict[str, Any], classification: Dict[str, Any]) -> float:
        """Deterministic baseline probability calculation."""
        base_prob = 0.55
        base_prob += classification.get("default_recovery_boost", 0.0)
        
        # Customer success rate
        succ_rate = cust_dict.get("historical_success_rate", 0.8)
        base_prob += (succ_rate - 0.7) * 0.4
        
        # Retry count penalty
        retry_count = int(txn_dict.get("retry_count", 0))
        base_prob -= retry_count * 0.18
        
        return round(float(np.clip(base_prob, 0.05, 0.95)), 4)

    def _determine_strategy(self, txn_dict: Dict[str, Any], prob: float, classification: Dict[str, Any]) -> str:
        amount = float(txn_dict.get("amount", 1000.0))
        retry_count = int(txn_dict.get("retry_count", 0))
        failure_reason = classification["failure_reason"]
        
        if amount > 25000 or retry_count >= 3:
            return "ESCALATE_TO_HUMAN"
        elif failure_reason in ["BANK_TIMEOUT", "UPI_FAILURE"]:
            return "RETRY_LATER" if retry_count < 2 else "ESCALATE_TO_HUMAN"
        elif failure_reason in ["NETWORK_ERROR", "GATEWAY_ERROR"]:
            return "RETRY_NOW" if retry_count == 0 else "RETRY_LATER"
        elif failure_reason in ["INSUFFICIENT_FUNDS", "CUSTOMER_ABANDONED"]:
            return "SEND_PAYMENT_REMINDER"
        elif failure_reason in ["CARD_EXPIRED", "BANK_DECLINED", "INVALID_DETAILS"]:
            return "SUGGEST_ALTERNATIVE_PAYMENT_METHOD"
        elif prob < 0.25:
            return "DO_NOT_RETRY"
        else:
            return "RETRY_LATER"

# Global singleton
predictor = RecoveryPredictor.get_instance()
