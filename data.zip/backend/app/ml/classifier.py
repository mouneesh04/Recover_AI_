from typing import Dict, Any

FAILURE_METADATA: Dict[str, Dict[str, Any]] = {
    "BANK_TIMEOUT": {
        "category": "TRANSIENT_INFRASTRUCTURE",
        "description": "Issuing bank server took too long to respond before transaction timeout.",
        "is_transient": True,
        "recommended_base_strategy": "RETRY_LATER",
        "default_recovery_boost": 0.25
    },
    "NETWORK_ERROR": {
        "category": "TRANSIENT_INFRASTRUCTURE",
        "description": "Network connection dropped between merchant checkout and gateway.",
        "is_transient": True,
        "recommended_base_strategy": "RETRY_NOW",
        "default_recovery_boost": 0.22
    },
    "GATEWAY_ERROR": {
        "category": "TRANSIENT_INFRASTRUCTURE",
        "description": "Payment aggregator returned internal 502/504 gateway exception.",
        "is_transient": True,
        "recommended_base_strategy": "RETRY_NOW",
        "default_recovery_boost": 0.20
    },
    "UPI_FAILURE": {
        "category": "PSP_TIMEOUT",
        "description": "UPI NPCI switch or bank PSP application failed to acknowledge transaction.",
        "is_transient": True,
        "recommended_base_strategy": "RETRY_LATER",
        "default_recovery_boost": 0.18
    },
    "INSUFFICIENT_FUNDS": {
        "category": "CUSTOMER_ACCOUNT",
        "description": "Account balance was insufficient at time of debit attempt.",
        "is_transient": False,
        "recommended_base_strategy": "SEND_PAYMENT_REMINDER",
        "default_recovery_boost": 0.05
    },
    "CUSTOMER_ABANDONED": {
        "category": "CUSTOMER_BEHAVIOR",
        "description": "Customer exited checkout before completing 2FA or OTP verification.",
        "is_transient": False,
        "recommended_base_strategy": "SEND_PAYMENT_REMINDER",
        "default_recovery_boost": 0.10
    },
    "BANK_DECLINED": {
        "category": "BANK_POLICY",
        "description": "Issuing bank rejected debit (e.g. international limits, risk lock).",
        "is_transient": False,
        "recommended_base_strategy": "SUGGEST_ALTERNATIVE_PAYMENT_METHOD",
        "default_recovery_boost": -0.15
    },
    "CARD_EXPIRED": {
        "category": "PERMANENT_INSTRUMENT",
        "description": "Card expiry date is in the past.",
        "is_transient": False,
        "recommended_base_strategy": "SUGGEST_ALTERNATIVE_PAYMENT_METHOD",
        "default_recovery_boost": -0.40
    },
    "INVALID_DETAILS": {
        "category": "CUSTOMER_INPUT",
        "description": "Invalid card number, CVV, or authentication details entered.",
        "is_transient": False,
        "recommended_base_strategy": "SUGGEST_ALTERNATIVE_PAYMENT_METHOD",
        "default_recovery_boost": -0.35
    },
    "UNKNOWN": {
        "category": "UNCLASSIFIED",
        "description": "Unclassified gateway error response.",
        "is_transient": False,
        "recommended_base_strategy": "ESCALATE_TO_HUMAN",
        "default_recovery_boost": -0.10
    }
}

def classify_failure(raw_reason: str, raw_code: str = None) -> Dict[str, Any]:
    """
    Classifies a raw failure reason into normalized taxonomy and recovery metadata.
    """
    reason_upper = (raw_reason or "").upper().strip()
    
    matched_reason = "UNKNOWN"
    for key in FAILURE_METADATA:
        if key in reason_upper or reason_upper in key:
            matched_reason = key
            break
            
    info = FAILURE_METADATA.get(matched_reason, FAILURE_METADATA["UNKNOWN"])
    
    return {
        "failure_reason": matched_reason,
        "category": info["category"],
        "description": info["description"],
        "is_transient": info["is_transient"],
        "recommended_base_strategy": info["recommended_base_strategy"]
    }
