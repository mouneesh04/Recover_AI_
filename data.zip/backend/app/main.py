import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.app.config import settings
from backend.app.api.routes import api_router
from backend.app.database.connection import engine, Base
from backend.app.ml.inference import RecoveryPredictor

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure database tables exist
    Base.metadata.create_all(bind=engine)
    # Warm up ML model
    RecoveryPredictor.get_instance().load_model()
    print(f"[RecoverAI] Backend initialized in {settings.ENVIRONMENT} mode.")
    yield
    print("[RecoverAI] Backend shutting down.")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Autonomous Failed Payment Recovery Agent Platform — AI Revenue Recovery",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include core API routes
app.include_router(api_router)

@app.get("/health", tags=["System"])
def health_check():
    """Health check endpoint for monitoring and container readiness."""
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "disclaimer": "Demo Environment — No real financial transactions are processed."
    }

@app.get("/", tags=["System"])
def root_info():
    """System information & landing endpoint."""
    return {
        "name": settings.PROJECT_NAME,
        "tagline": "Turn Failed Payments Into Recovered Revenue.",
        "docs": "/docs",
        "health": "/health",
        "track": "AI Revenue Recovery"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True
    )
