from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.app.models.customer import Customer
from backend.app.models.transaction import Transaction
from backend.app.schemas.customer import CustomerRead, CustomerDetail
from backend.app.schemas.transaction import TransactionRead

class CustomerService:
    @staticmethod
    def get_customers(db: Session, page: int = 1, page_size: int = 20) -> List[CustomerRead]:
        offset = (page - 1) * page_size
        customers = db.query(Customer).order_by(desc(Customer.total_transactions)).offset(offset).limit(page_size).all()
        return [CustomerRead.model_validate(c) for c in customers]

    @staticmethod
    def get_customer_detail(db: Session, customer_id: str) -> Optional[CustomerDetail]:
        cust = db.query(Customer).filter(Customer.id == customer_id).first()
        if not cust:
            return None
            
        recent_txns = db.query(Transaction).filter(Transaction.customer_id == customer_id)\
            .order_by(desc(Transaction.created_at)).limit(10).all()
            
        txns_read = [
            TransactionRead(
                id=t.id,
                customer_id=t.customer_id,
                customer_name=cust.name,
                customer_email=cust.email,
                amount=t.amount,
                currency=t.currency,
                payment_method=t.payment_method,
                status=t.status,
                failure_reason=t.failure_reason,
                retry_count=t.retry_count,
                recovery_probability=t.recovery_probability,
                risk_level=t.risk_level or "LOW",
                recommended_strategy=t.recommended_strategy,
                created_at=t.created_at
            )
            for t in recent_txns
        ]
        
        detail = CustomerDetail.model_validate(cust)
        detail.recent_transactions = txns_read
        return detail
