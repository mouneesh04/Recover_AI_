import os
import json
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from datetime import datetime, timedelta

from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.models.agent_decision import AgentDecision
from backend.app.schemas.dashboard import DashboardMetricsResponse, MetricSummary, ChartDataPoint, CategoryBreakdown
from backend.app.schemas.analytics import AnalyticsResponse, StrategyROI

class AnalyticsService:
    @staticmethod
    def get_dashboard_metrics(db: Session) -> DashboardMetricsResponse:
        total_txns = db.query(Transaction).count()
        successful_txns = db.query(Transaction).filter(Transaction.status == "SUCCESS").count()
        recovered_txns = db.query(Transaction).filter(Transaction.status == "RECOVERED").count()
        failed_txns = db.query(Transaction).filter(Transaction.status.in_(["FAILED", "RECOVERING", "RECOVERED", "NON_RECOVERABLE", "MANUAL_REVIEW"])).count()
        recoverable_txns = db.query(Transaction).filter(Transaction.recovery_probability >= 0.50).count()
        
        # Revenue aggregations
        revenue_at_risk_query = db.query(func.sum(Transaction.amount)).filter(
            Transaction.status.in_(["FAILED", "RECOVERING", "RECOVERED", "NON_RECOVERABLE", "MANUAL_REVIEW"])
        ).scalar()
        revenue_at_risk = float(revenue_at_risk_query or 0.0)
        
        revenue_recovered_query = db.query(func.sum(Transaction.amount)).filter(
            Transaction.status == "RECOVERED"
        ).scalar()
        revenue_recovered = float(revenue_recovered_query or 0.0)
        
        recovery_rate_pct = round((recovered_txns / max(1, failed_txns)) * 100, 1)
        
        pending_actions = db.query(RecoveryAction).filter(RecoveryAction.status == "PENDING").count()
        human_review_cases = db.query(Transaction).filter(Transaction.status == "MANUAL_REVIEW").count()
        
        metrics = MetricSummary(
            total_transactions=total_txns,
            successful_transactions=successful_txns,
            failed_transactions=failed_txns,
            recoverable_failed_transactions=recoverable_txns,
            recovered_count=recovered_txns,
            recovery_rate_pct=recovery_rate_pct,
            revenue_at_risk=round(revenue_at_risk, 2),
            revenue_recovered=round(revenue_recovered, 2),
            pending_recovery_actions=pending_actions,
            human_review_cases=human_review_cases,
            currency="INR"
        )
        
        # Build 7-day timeseries
        timeseries: List[ChartDataPoint] = []
        now = datetime.utcnow()
        for i in range(6, -1, -1):
            day_start = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            day_label = day_start.strftime("%b %d")
            
            day_failed = db.query(Transaction).filter(
                Transaction.created_at >= day_start,
                Transaction.created_at < day_end,
                Transaction.status.in_(["FAILED", "RECOVERING", "RECOVERED", "NON_RECOVERABLE", "MANUAL_REVIEW"])
            ).count()
            
            day_recovered = db.query(Transaction).filter(
                Transaction.recovered_at >= day_start,
                Transaction.recovered_at < day_end,
                Transaction.status == "RECOVERED"
            ).count()
            
            day_risk = float(db.query(func.sum(Transaction.amount)).filter(
                Transaction.created_at >= day_start,
                Transaction.created_at < day_end,
                Transaction.status.in_(["FAILED", "RECOVERING", "RECOVERED", "NON_RECOVERABLE", "MANUAL_REVIEW"])
            ).scalar() or 0.0)
            
            day_rec_rev = float(db.query(func.sum(Transaction.amount)).filter(
                Transaction.recovered_at >= day_start,
                Transaction.recovered_at < day_end,
                Transaction.status == "RECOVERED"
            ).scalar() or 0.0)
            
            day_rate = round((day_recovered / max(1, day_failed)) * 100, 1)
            
            timeseries.append(ChartDataPoint(
                date=day_label,
                failed_count=day_failed,
                recovered_count=day_recovered,
                revenue_at_risk=round(day_risk, 2),
                revenue_recovered=round(day_rec_rev, 2),
                recovery_rate=day_rate
            ))
            
        # Failure Reason breakdown
        failure_reasons_raw = db.query(Transaction.failure_reason, func.count(Transaction.id))\
            .filter(Transaction.failure_reason.isnot(None))\
            .group_by(Transaction.failure_reason).all()
            
        failure_reasons = []
        for reason, count in failure_reasons_raw:
            pct = round((count / max(1, failed_txns)) * 100, 1)
            rec_cnt = db.query(Transaction).filter(Transaction.failure_reason == reason, Transaction.status == "RECOVERED").count()
            rec_rev = float(db.query(func.sum(Transaction.amount)).filter(Transaction.failure_reason == reason, Transaction.status == "RECOVERED").scalar() or 0.0)
            failure_reasons.append(CategoryBreakdown(
                name=reason,
                count=count,
                percentage=pct,
                recovered_count=rec_cnt,
                revenue_recovered=round(rec_rev, 2)
            ))
            
        # Payment Method breakdown
        payment_methods_raw = db.query(Transaction.payment_method, func.count(Transaction.id))\
            .group_by(Transaction.payment_method).all()
            
        payment_methods = []
        for method, count in payment_methods_raw:
            pct = round((count / max(1, total_txns)) * 100, 1)
            rec_cnt = db.query(Transaction).filter(Transaction.payment_method == method, Transaction.status == "RECOVERED").count()
            rec_rev = float(db.query(func.sum(Transaction.amount)).filter(Transaction.payment_method == method, Transaction.status == "RECOVERED").scalar() or 0.0)
            payment_methods.append(CategoryBreakdown(
                name=method,
                count=count,
                percentage=pct,
                recovered_count=rec_cnt,
                revenue_recovered=round(rec_rev, 2)
            ))
            
        # Recovery Strategy breakdown
        strategies_raw = db.query(Transaction.recommended_strategy, func.count(Transaction.id))\
            .filter(Transaction.recommended_strategy.isnot(None))\
            .group_by(Transaction.recommended_strategy).all()
            
        recovery_strategies = []
        for strat, count in strategies_raw:
            pct = round((count / max(1, failed_txns)) * 100, 1)
            rec_cnt = db.query(Transaction).filter(Transaction.recommended_strategy == strat, Transaction.status == "RECOVERED").count()
            rec_rev = float(db.query(func.sum(Transaction.amount)).filter(Transaction.recommended_strategy == strat, Transaction.status == "RECOVERED").scalar() or 0.0)
            recovery_strategies.append(CategoryBreakdown(
                name=strat,
                count=count,
                percentage=pct,
                recovered_count=rec_cnt,
                revenue_recovered=round(rec_rev, 2)
            ))
            
        return DashboardMetricsResponse(
            metrics=metrics,
            timeseries=timeseries,
            failure_reasons=failure_reasons,
            payment_methods=payment_methods,
            recovery_strategies=recovery_strategies
        )

    @staticmethod
    def get_deep_analytics(db: Session) -> AnalyticsResponse:
        # Strategy ROI
        strategies = ["RETRY_NOW", "RETRY_LATER", "SEND_PAYMENT_REMINDER", "SUGGEST_ALTERNATIVE_PAYMENT_METHOD", "ESCALATE_TO_HUMAN"]
        strategy_rois: List[StrategyROI] = []
        
        for strat in strategies:
            attempted = db.query(RecoveryAction).filter(RecoveryAction.action_type == strat).count()
            successes = db.query(RecoveryResult).join(RecoveryAction, RecoveryResult.action_id == RecoveryAction.id)\
                .filter(RecoveryAction.action_type == strat, RecoveryResult.outcome == "SUCCESS").count()
            rev = float(db.query(func.sum(RecoveryResult.recovered_amount)).join(RecoveryAction, RecoveryResult.action_id == RecoveryAction.id)\
                .filter(RecoveryAction.action_type == strat, RecoveryResult.outcome == "SUCCESS").scalar() or 0.0)
            rate = round((successes / max(1, attempted)) * 100, 1)
            
            strategy_rois.append(StrategyROI(
                strategy=strat,
                attempted_count=attempted,
                success_count=successes,
                success_rate=rate,
                revenue_recovered=round(rev, 2),
                avg_recovery_time_mins=12.5 if strat == "RETRY_LATER" else (1.2 if strat == "RETRY_NOW" else 45.0)
            ))
            
        # Amount Tier breakdown
        tiers = [
            {"tier": "Under ₹1,000", "min": 0, "max": 1000},
            {"tier": "₹1,000 - ₹5,000", "min": 1000, "max": 5000},
            {"tier": "₹5,000 - ₹15,000", "min": 5000, "max": 15000},
            {"tier": "₹15,000 - ₹25,000", "min": 15000, "max": 25000},
            {"tier": "Above ₹25,000", "min": 25000, "max": 999999999},
        ]
        tier_data = []
        for t in tiers:
            count = db.query(Transaction).filter(Transaction.amount >= t["min"], Transaction.amount < t["max"]).count()
            rec = db.query(Transaction).filter(Transaction.amount >= t["min"], Transaction.amount < t["max"], Transaction.status == "RECOVERED").count()
            rate = round((rec / max(1, count)) * 100, 1)
            tier_data.append({"tier": t["tier"], "total_count": count, "recovered_count": rec, "recovery_rate": rate})
            
        # Customer Type breakdown
        cust_types = ["VIP", "PREMIUM", "STANDARD"]
        cust_data = []
        for ctype in cust_types:
            count = db.query(Transaction).join(Customer, Transaction.customer_id == Customer.id).filter(Customer.tier == ctype).count()
            rec = db.query(Transaction).join(Customer, Transaction.customer_id == Customer.id).filter(Customer.tier == ctype, Transaction.status == "RECOVERED").count()
            rate = round((rec / max(1, count)) * 100, 1)
            cust_data.append({"customer_tier": ctype, "total_count": count, "recovered_count": rec, "recovery_rate": rate})
            
        # Load ML model report from file if present
        eval_file = "ml/artifacts/evaluation_report.json"
        ml_metrics = {}
        if os.path.exists(eval_file):
            try:
                with open(eval_file, "r") as f:
                    ml_metrics = json.load(f)
            except Exception:
                ml_metrics = {}

        return AnalyticsResponse(
            strategy_roi=strategy_rois,
            recovery_by_amount_tier=tier_data,
            recovery_by_customer_type=cust_data,
            failure_recovery_matrix=[],
            ml_model_metrics=ml_metrics
        )
