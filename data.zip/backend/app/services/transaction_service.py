from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from datetime import datetime

from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.recovery_result import RecoveryResult
from backend.app.schemas.transaction import TransactionRead, TransactionListResponse, TimelineEvent, TransactionTimelineResponse

class TransactionService:
    @staticmethod
    def get_transactions(
        db: Session,
        status: Optional[str] = None,
        failure_reason: Optional[str] = None,
        payment_method: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        page_size: int = 15
    ) -> TransactionListResponse:
        query = db.query(Transaction, Customer.name.label("customer_name"), Customer.email.label("customer_email"))\
            .join(Customer, Transaction.customer_id == Customer.id)
            
        if status and status != "ALL":
            query = query.filter(Transaction.status == status)
            
        if failure_reason and failure_reason != "ALL":
            query = query.filter(Transaction.failure_reason == failure_reason)
            
        if payment_method and payment_method != "ALL":
            query = query.filter(Transaction.payment_method == payment_method)
            
        if search:
            search_fmt = f"%{search}%"
            query = query.filter(
                (Transaction.id.ilike(search_fmt)) |
                (Customer.name.ilike(search_fmt)) |
                (Customer.email.ilike(search_fmt)) |
                (Transaction.customer_id.ilike(search_fmt))
            )
            
        total = query.count()
        total_pages = max(1, (total + page_size - 1) // page_size)
        
        offset = (page - 1) * page_size
        results = query.order_by(desc(Transaction.created_at)).offset(offset).limit(page_size).all()
        
        items = []
        for txn, cust_name, cust_email in results:
            item = TransactionRead(
                id=txn.id,
                customer_id=txn.customer_id,
                customer_name=cust_name,
                customer_email=cust_email,
                amount=txn.amount,
                currency=txn.currency,
                payment_method=txn.payment_method,
                status=txn.status,
                failure_reason=txn.failure_reason,
                failure_code=txn.failure_code,
                retry_count=txn.retry_count,
                max_retries=txn.max_retries,
                recovery_probability=txn.recovery_probability,
                risk_level=txn.risk_level or "LOW",
                recommended_strategy=txn.recommended_strategy,
                device_type=txn.device_type,
                ip_location=txn.ip_location,
                network_latency_ms=txn.network_latency_ms,
                bank_response_time_ms=txn.bank_response_time_ms,
                failed_at=txn.failed_at,
                recovered_at=txn.recovered_at,
                created_at=txn.created_at
            )
            items.append(item)
            
        return TransactionListResponse(
            items=items,
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages
        )

    @staticmethod
    def get_transaction_by_id(db: Session, transaction_id: str) -> Optional[Dict[str, Any]]:
        txn_tuple = db.query(Transaction, Customer)\
            .join(Customer, Transaction.customer_id == Customer.id)\
            .filter(Transaction.id == transaction_id).first()
            
        if not txn_tuple:
            return None
            
        txn, cust = txn_tuple
        
        # Latest agent decision
        decision = db.query(AgentDecision)\
            .filter(AgentDecision.transaction_id == transaction_id)\
            .order_by(desc(AgentDecision.created_at)).first()
            
        # Recovery actions
        actions = db.query(RecoveryAction)\
            .filter(RecoveryAction.transaction_id == transaction_id)\
            .order_by(RecoveryAction.created_at).all()
            
        return {
            "transaction": txn,
            "customer": cust,
            "latest_decision": decision,
            "actions": actions
        }

    @staticmethod
    def build_timeline(db: Session, transaction_id: str) -> TransactionTimelineResponse:
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if not txn:
            return TransactionTimelineResponse(transaction_id=transaction_id, current_status="NOT_FOUND", events=[])
            
        events: List[TimelineEvent] = []
        step = 1
        
        # 1. Payment Failed
        events.append(TimelineEvent(
            step=step,
            timestamp=txn.failed_at or txn.created_at,
            title="Payment Failed",
            description=f"Transaction failed via {txn.payment_method} due to {txn.failure_reason or 'UNKNOWN'}.",
            type="FAILED",
            status="FAILED",
            metadata={"amount": txn.amount, "currency": txn.currency}
        ))
        step += 1
        
        # 2. Failure Diagnosed & Analyzed
        decisions = db.query(AgentDecision).filter(AgentDecision.transaction_id == transaction_id).order_by(AgentDecision.created_at).all()
        for dec in decisions:
            events.append(TimelineEvent(
                step=step,
                timestamp=dec.created_at,
                title="AI Failure Analysis & Recovery Scoring",
                description=f"RecoverAI calculated {dec.confidence*100:.0f}% recovery probability. Strategy selected: {dec.strategy_chosen}.",
                type="ANALYZED",
                status="SUCCESS",
                metadata={"confidence": dec.confidence, "strategy": dec.strategy_chosen, "reasoning": dec.reasoning_text}
            ))
            step += 1
            
        # 3. Recovery Actions & Results
        actions = db.query(RecoveryAction).filter(RecoveryAction.transaction_id == transaction_id).order_by(RecoveryAction.created_at).all()
        for act in actions:
            # Check corresponding result
            res = db.query(RecoveryResult).filter(RecoveryResult.action_id == act.id).first()
            if act.action_type in ["RETRY_NOW", "RETRY_LATER"]:
                events.append(TimelineEvent(
                    step=step,
                    timestamp=act.executed_at or act.created_at,
                    title=f"Payment Retry Executed ({act.action_type})",
                    description=act.execution_summary or f"Simulated gateway retry executed.",
                    type="ACTION_EXECUTED",
                    status="SUCCESS" if (res and res.outcome == "SUCCESS") else "FAILED",
                    metadata={"outcome": res.outcome if res else "PENDING", "latency_ms": res.latency_ms if res else 0}
                ))
            elif act.action_type == "SEND_PAYMENT_REMINDER":
                events.append(TimelineEvent(
                    step=step,
                    timestamp=act.executed_at or act.created_at,
                    title="Customer Payment Reminder Dispatched",
                    description=act.execution_summary or "Personalized payment reminder sent.",
                    type="REMINDER_SENT",
                    status="SUCCESS"
                ))
            elif act.action_type == "SUGGEST_ALTERNATIVE_PAYMENT_METHOD":
                events.append(TimelineEvent(
                    step=step,
                    timestamp=act.executed_at or act.created_at,
                    title="Alternative Payment Checkout Generated",
                    description=act.execution_summary or "Smart recovery link dispatched.",
                    type="ACTION_EXECUTED",
                    status="SUCCESS"
                ))
            elif act.action_type == "ESCALATE_TO_HUMAN":
                events.append(TimelineEvent(
                    step=step,
                    timestamp=act.created_at,
                    title="Routed to Human Review Queue",
                    description=act.execution_summary or "Action held for merchant approval.",
                    type="ESCALATED",
                    status="INFO"
                ))
            step += 1
            
        # 4. Final State
        if txn.status == "RECOVERED":
            events.append(TimelineEvent(
                step=step,
                timestamp=txn.recovered_at or datetime.utcnow(),
                title="Revenue Successfully Recovered",
                description=f"₹{txn.amount:,.2f} captured and restored to merchant balance.",
                type="RECOVERED",
                status="SUCCESS",
                metadata={"recovered_amount": txn.amount}
            ))
            
        return TransactionTimelineResponse(
            transaction_id=transaction_id,
            current_status=txn.status,
            events=events
        )
