import json
import uuid
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime

from backend.app.models.transaction import Transaction
from backend.app.models.customer import Customer
from backend.app.models.agent_decision import AgentDecision
from backend.app.models.recovery_action import RecoveryAction
from backend.app.models.audit_log import AuditLog
from backend.app.schemas.recovery import HumanReviewItem
from backend.app.agents.tools import AgentToolRegistry

class RecoveryService:
    @staticmethod
    def get_human_review_queue(db: Session) -> List[HumanReviewItem]:
        """Fetches transactions that require human operator review."""
        txns = db.query(Transaction, Customer)\
            .join(Customer, Transaction.customer_id == Customer.id)\
            .filter(Transaction.status == "MANUAL_REVIEW")\
            .order_by(desc(Transaction.amount))\
            .all()
            
        items = []
        for txn, cust in txns:
            # Latest decision
            dec = db.query(AgentDecision)\
                .filter(AgentDecision.transaction_id == txn.id)\
                .order_by(desc(AgentDecision.created_at)).first()
                
            factors = []
            if dec and dec.factors_json:
                try:
                    factors = json.loads(dec.factors_json)
                except Exception:
                    factors = []
                    
            escalation_reason = dec.reasoning_text if dec else "Requires operator confirmation before recovery."
            
            items.append(HumanReviewItem(
                id=txn.id,
                customer_id=cust.id,
                customer_name=cust.name,
                customer_tier=cust.tier,
                amount=txn.amount,
                currency=txn.currency,
                payment_method=txn.payment_method,
                failure_reason=txn.failure_reason or "UNKNOWN",
                retry_count=txn.retry_count,
                recovery_probability=txn.recovery_probability or 0.5,
                recommended_strategy=txn.recommended_strategy or "RETRY_LATER",
                escalation_reason=escalation_reason,
                risk_level=txn.risk_level or "MEDIUM",
                created_at=txn.created_at,
                factors=factors
            ))
            
        return items

    @staticmethod
    def approve_action(db: Session, transaction_id: str, custom_strategy: Optional[str] = None, notes: Optional[str] = None) -> Dict[str, Any]:
        """Merchant operator approves recovery action for high-value or escalated transaction."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if not txn:
            return {"error": "Transaction not found."}
            
        strategy = custom_strategy or txn.recommended_strategy or "RETRY_NOW"
        
        # Log merchant audit approval
        audit_id = f"AUD-{uuid.uuid4().hex[:8].upper()}"
        audit = AuditLog(
            id=audit_id,
            actor="MERCHANT",
            action="APPROVE_RECOVERY",
            entity_type="TRANSACTION",
            entity_id=transaction_id,
            reason=notes or f"Merchant manually approved recovery via {strategy}.",
            details_json=json.dumps({"strategy": strategy, "amount": txn.amount})
        )
        db.add(audit)
        
        # Execute tool retry
        retry_res = AgentToolRegistry.retry_payment(
            transaction_id=transaction_id,
            amount=txn.amount,
            payment_method=txn.payment_method,
            failure_reason=txn.failure_reason,
            retry_count=txn.retry_count,
            db=db
        )
        
        # Update latest decision status if exists
        dec = db.query(AgentDecision).filter(AgentDecision.transaction_id == transaction_id).order_by(desc(AgentDecision.created_at)).first()
        if dec:
            dec.approval_status = "APPROVED"
            
        db.commit()
        
        return {
            "status": "APPROVED",
            "transaction_id": transaction_id,
            "strategy": strategy,
            "execution_result": retry_res
        }

    @staticmethod
    def reject_action(db: Session, transaction_id: str, reason: str) -> Dict[str, Any]:
        """Merchant operator rejects recovery action, marking transaction as non-recoverable."""
        txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
        if not txn:
            return {"error": "Transaction not found."}
            
        txn.status = "NON_RECOVERABLE"
        
        # Update latest decision
        dec = db.query(AgentDecision).filter(AgentDecision.transaction_id == transaction_id).order_by(desc(AgentDecision.created_at)).first()
        if dec:
            dec.approval_status = "REJECTED"
            
        audit_id = f"AUD-{uuid.uuid4().hex[:8].upper()}"
        audit = AuditLog(
            id=audit_id,
            actor="MERCHANT",
            action="REJECT_RECOVERY",
            entity_type="TRANSACTION",
            entity_id=transaction_id,
            reason=reason,
            details_json=json.dumps({"status": "NON_RECOVERABLE"})
        )
        db.add(audit)
        db.commit()
        
        return {
            "status": "REJECTED",
            "transaction_id": transaction_id,
            "reason": reason
        }
