import pytest
from backend.app.ml.inference import predictor
from backend.app.ml.classifier import classify_failure

def test_failure_classification():
    diag = classify_failure("BANK_TIMEOUT")
    assert diag["failure_reason"] == "BANK_TIMEOUT"
    assert diag["is_transient"] is True
    assert diag["recommended_base_strategy"] == "RETRY_LATER"

def test_ml_inference_transient():
    txn_dict = {
        "amount": 8999.0,
        "payment_method": "UPI",
        "device_type": "MOBILE",
        "hour": 14,
        "day_of_week": 2,
        "retry_count": 0,
        "network_latency_ms": 110,
        "bank_response_time_ms": 3500,
        "failure_reason": "BANK_TIMEOUT"
    }
    cust_dict = {
        "total_transactions": 14,
        "successful_transactions": 12,
        "failed_transactions": 2,
        "historical_success_rate": 0.86,
        "avg_transaction_amount": 7500.0,
        "customer_age_days": 180
    }
    
    result = predictor.predict(txn_dict, cust_dict)
    assert result["recovery_probability"] >= 0.70
    assert result["recoverable"] is True
    assert result["recommended_strategy"] == "RETRY_LATER"
    assert len(result["key_factors"]) > 0
