import pytest
from backend.app.database.connection import SessionLocal
from backend.app.agents.recovery_agent import AutonomousRecoveryAgent
from backend.app.database.seed_data import seed_database
from backend.app.models.transaction import Transaction

def test_autonomous_recovery_agent_demo_scenario():
    # 1. Reset database with demo scenario
    seed_database()
    
    db = SessionLocal()
    try:
        # Verify initial state of TXN-DEMO-001
        txn_before = db.query(Transaction).filter(Transaction.id == "TXN-DEMO-001").first()
        assert txn_before.status == "FAILED"
        assert txn_before.retry_count == 0
        
        # 2. Run agent recovery loop
        agent = AutonomousRecoveryAgent(db=db)
        state = agent.run_recovery_loop(transaction_id="TXN-DEMO-001")
        
        # 3. Assert agent decision & state transitions
        assert state.transaction_id == "TXN-DEMO-001"
        assert state.recovery_probability >= 0.85
        assert state.strategy_chosen in ["RETRY_LATER", "RETRY_NOW"]
        assert state.final_outcome == "RECOVERED"
        assert state.recovered_amount == 8999.0
        assert len(state.tool_history) >= 4
        
        # 4. Verify database persistence
        txn_after = db.query(Transaction).filter(Transaction.id == "TXN-DEMO-001").first()
        assert txn_after.status == "RECOVERED"
        assert txn_after.recovered_at is not None
        assert txn_after.retry_count == 1
    finally:
        db.close()
