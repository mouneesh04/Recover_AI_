import pytest
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "RecoverAI" in data["service"]

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["tagline"] == "Turn Failed Payments Into Recovered Revenue."

def test_dashboard_metrics():
    response = client.get("/api/dashboard/metrics")
    assert response.status_code == 200
    data = response.json()
    assert "metrics" in data
    assert "timeseries" in data
    assert "failure_reasons" in data
    assert data["metrics"]["total_transactions"] >= 0

def test_list_transactions():
    response = client.get("/api/transactions?page=1&page_size=10")
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "total" in data
    assert len(data["items"]) <= 10

def test_seed_demo_and_fetch_details():
    seed_res = client.post("/api/simulator/seed-demo")
    assert seed_res.status_code == 200
    
    get_res = client.get("/api/transactions/TXN-DEMO-001")
    assert get_res.status_code == 200
    txn_data = get_res.json()
    assert txn_data["transaction"]["id"] == "TXN-DEMO-001"
    assert txn_data["transaction"]["amount"] == 8999.0
    assert txn_data["customer"]["name"] == "Rahul Sharma"
