import pytest
from backend.app.agents.policies import policy_engine

def test_high_value_guardrail():
    # Transaction amount ₹60,000 exceeds ₹25,000 threshold
    res = policy_engine.evaluate(
        amount=60000.0,
        retry_count=0,
        recovery_probability=0.92,
        current_status="FAILED",
        failure_reason="BANK_TIMEOUT"
    )
    assert res.is_safe is False
    assert res.requires_human_approval is True
    assert res.rejection_code == "HIGH_VALUE_THRESHOLD"

def test_max_retries_guardrail():
    # Retry count 3 reaches limit
    res = policy_engine.evaluate(
        amount=5000.0,
        retry_count=3,
        recovery_probability=0.80,
        current_status="FAILED",
        failure_reason="BANK_TIMEOUT"
    )
    assert res.is_safe is False
    assert res.requires_human_approval is True
    assert res.rejection_code == "MAX_RETRIES_EXCEEDED"

def test_low_confidence_guardrail():
    # Recovery probability 0.15 is below 0.35 threshold
    res = policy_engine.evaluate(
        amount=3000.0,
        retry_count=1,
        recovery_probability=0.15,
        current_status="FAILED",
        failure_reason="CARD_EXPIRED"
    )
    assert res.is_safe is False
    assert res.requires_human_approval is True
    assert res.rejection_code == "LOW_CONFIDENCE"

def test_safe_transaction_approval():
    # Safe normal transaction
    res = policy_engine.evaluate(
        amount=8999.0,
        retry_count=0,
        recovery_probability=0.91,
        current_status="FAILED",
        failure_reason="BANK_TIMEOUT"
    )
    assert res.is_safe is True
    assert res.requires_human_approval is False
